#include "TouRTOS/framework/Semaphore.h"

#include <chrono>

#include "TouRTOS/framework/Task.h"
#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

CountingSemaphore::CountingSemaphore(std::size_t initial_count, std::size_t max_count) noexcept
    : count_(initial_count), max_count_(max_count) {}

bool CountingSemaphore::take(std::uint32_t timeout_ms) noexcept {
    auto& kernel = Kernel::SystemKernel::instance();
    Task* task = Task::current();
    const auto deadline = timeout_ms == Kernel::Config::WaitForever
        ? static_cast<Kernel::Tick>(0U)
        : kernel.tickEngine().now() + kernel.tickEngine().msToTicks(timeout_ms);

    std::unique_lock<std::mutex> lock(mutex_);
    while (count_ == 0U) {
        if (task != nullptr) {
            kernel.scheduler().blockTask(task->controlBlock(), deadline);
        }
        if (deadline != 0U && kernel.tickEngine().now() >= deadline) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return false;
        }
        if (kernel.stopRequested()) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return false;
        }
        cv_.wait_for(lock, std::chrono::milliseconds(1));
    }

    --count_;
    if (task != nullptr) {
        kernel.scheduler().makeReady(task->controlBlock());
    }
    return true;
}

bool CountingSemaphore::tryTake() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (count_ == 0U) {
        return false;
    }
    --count_;
    return true;
}

void CountingSemaphore::give() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (count_ < max_count_) {
        ++count_;
        cv_.notify_one();
    }
}

std::size_t CountingSemaphore::count() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return count_;
}

}  // namespace TouRTOS
