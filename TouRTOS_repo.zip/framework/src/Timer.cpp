#include "TouRTOS/framework/Timer.h"

#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

void Timer::start() noexcept {
    auto& kernel = Kernel::SystemKernel::instance();
    timer_.start(kernel.tickEngine().now(), kernel.tickEngine().msToTicks(timer_.periodMilliseconds()));
}

void Timer::stop() noexcept {
    timer_.stop();
}

void Timer::restart() noexcept {
    stop();
    start();
}

bool Timer::active() const noexcept {
    return timer_.active();
}

const char* Timer::name() const noexcept {
    return timer_.name();
}

std::uint32_t Timer::periodMilliseconds() const noexcept {
    return timer_.periodMilliseconds();
}

void Timer::registerWithKernel() noexcept {
    Kernel::SystemKernel::instance().registerTimer(timer_);
}

}  // namespace TouRTOS
