#include "TouRTOS/framework/EventFlags.h"

#include <chrono>

#include "TouRTOS/framework/Task.h"
#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

void EventFlags::set(std::uint32_t mask) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    flags_ |= mask;
    cv_.notify_all();
}

void EventFlags::clear(std::uint32_t mask) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    flags_ &= ~mask;
}

std::uint32_t EventFlags::get() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return flags_;
}

std::uint32_t EventFlags::waitAny(std::uint32_t mask, std::uint32_t timeout_ms, bool auto_clear) noexcept {
    auto& kernel = Kernel::SystemKernel::instance();
    Task* task = Task::current();
    const auto deadline = timeout_ms == Kernel::Config::WaitForever
        ? static_cast<Kernel::Tick>(0U)
        : kernel.tickEngine().now() + kernel.tickEngine().msToTicks(timeout_ms);

    std::unique_lock<std::mutex> lock(mutex_);
    while ((flags_ & mask) == 0U) {
        if (task != nullptr) {
            kernel.scheduler().blockTask(task->controlBlock(), deadline);
        }
        if ((deadline != 0U && kernel.tickEngine().now() >= deadline) || kernel.stopRequested()) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return 0U;
        }
        cv_.wait_for(lock, std::chrono::milliseconds(1));
    }

    const std::uint32_t result = flags_ & mask;
    if (auto_clear) {
        flags_ &= ~result;
    }
    if (task != nullptr) {
        kernel.scheduler().makeReady(task->controlBlock());
    }
    return result;
}

std::uint32_t EventFlags::waitAll(std::uint32_t mask, std::uint32_t timeout_ms, bool auto_clear) noexcept {
    auto& kernel = Kernel::SystemKernel::instance();
    Task* task = Task::current();
    const auto deadline = timeout_ms == Kernel::Config::WaitForever
        ? static_cast<Kernel::Tick>(0U)
        : kernel.tickEngine().now() + kernel.tickEngine().msToTicks(timeout_ms);

    std::unique_lock<std::mutex> lock(mutex_);
    while ((flags_ & mask) != mask) {
        if (task != nullptr) {
            kernel.scheduler().blockTask(task->controlBlock(), deadline);
        }
        if ((deadline != 0U && kernel.tickEngine().now() >= deadline) || kernel.stopRequested()) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return 0U;
        }
        cv_.wait_for(lock, std::chrono::milliseconds(1));
    }

    const std::uint32_t result = flags_ & mask;
    if (auto_clear) {
        flags_ &= ~mask;
    }
    if (task != nullptr) {
        kernel.scheduler().makeReady(task->controlBlock());
    }
    return result;
}

}  // namespace TouRTOS
