#include "TouRTOS/framework/Mutex.h"

#include <chrono>

#include "TouRTOS/framework/Task.h"
#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

bool Mutex::lock(std::uint32_t timeout_ms) noexcept {
    auto& kernel = Kernel::SystemKernel::instance();
    Task* task = Task::current();
    const auto deadline = timeout_ms == Kernel::Config::WaitForever
        ? static_cast<Kernel::Tick>(0U)
        : kernel.tickEngine().now() + kernel.tickEngine().msToTicks(timeout_ms);

    std::unique_lock<std::mutex> lock(mutex_);
    while (locked_) {
        if (task != nullptr) {
            kernel.scheduler().blockTask(task->controlBlock(), deadline);
        }
        if (deadline != 0U && kernel.tickEngine().now() >= deadline) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return false;
        }
        if (kernel.stopRequested()) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return false;
        }
        cv_.wait_for(lock, std::chrono::milliseconds(1));
    }

    locked_ = true;
    owner_ = std::this_thread::get_id();
    if (task != nullptr) {
        kernel.scheduler().makeReady(task->controlBlock());
    }
    return true;
}

bool Mutex::tryLock() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (locked_) {
        return false;
    }
    locked_ = true;
    owner_ = std::this_thread::get_id();
    return true;
}

void Mutex::unlock() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (locked_ && owner_ == std::this_thread::get_id()) {
        locked_ = false;
        owner_ = std::thread::id{};
        cv_.notify_one();
    }
}

}  // namespace TouRTOS
