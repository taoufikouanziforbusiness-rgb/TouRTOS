#include "TouRTOS/framework/Task.h"

#if TOURTOS_USE_HOST_RUNTIME
#include <chrono>
#include <thread>
#endif

#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

namespace {
std::atomic<Kernel::TaskId> g_next_task_id{1U};
thread_local Task* g_current_task = nullptr;
}  // namespace

Task::~Task() noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    if (thread_.joinable()) {
        thread_.detach();
    }
#endif
}

void Task::start() noexcept {
    if (started_.exchange(true)) {
        return;
    }

    Kernel::SystemKernel::instance().registerTask(control_block_);
#if TOURTOS_USE_HOST_RUNTIME
    thread_ = std::thread(&Task::threadMain, this);
#else
    Kernel::SystemKernel::instance().scheduler().makeReady(control_block_);
#endif
}

void Task::join() noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    if (thread_.joinable()) {
        thread_.join();
    }
#endif
}

bool Task::joinable() const noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    return thread_.joinable();
#else
    return false;
#endif
}

void Task::suspend() noexcept {
    suspended_.store(true);
    Kernel::SystemKernel::instance().scheduler().suspendTask(control_block_);
}

void Task::resume() noexcept {
    suspended_.store(false);
    Kernel::SystemKernel::instance().scheduler().resumeTask(control_block_);
}

bool Task::stopRequested() const noexcept {
    return Kernel::SystemKernel::instance().stopRequested();
}

void Task::setPriority(std::size_t priority) noexcept {
    control_block_.priority = Kernel::Config::clampPriority(priority);
}

void Task::setStackSize(std::size_t stack_size) noexcept {
    control_block_.stack_size = Kernel::Config::clampTaskStackSize(stack_size);
}

void Task::setHandle(TaskHandle* handle) noexcept {
    control_block_.handle = handle;
    if (handle != nullptr) {
        handle->task_ = this;
    }
}

void Task::setName(const char* name) noexcept {
    name_ = name;
    control_block_.name = name;
}

const char* Task::name() const noexcept {
    return name_;
}

std::size_t Task::priority() const noexcept {
    return control_block_.priority;
}

Kernel::TaskControlBlock& Task::controlBlock() noexcept {
    return control_block_;
}

const Kernel::TaskControlBlock& Task::controlBlock() const noexcept {
    return control_block_;
}

void Task::sleep(std::uint32_t milliseconds) noexcept {
    Task* task = current();
    if (task == nullptr) {
#if TOURTOS_USE_HOST_RUNTIME
        std::this_thread::sleep_for(std::chrono::milliseconds(milliseconds));
#else
        Kernel::SystemKernel::instance().advanceTicks(milliseconds);
#endif
        return;
    }

    Kernel::SystemKernel::instance().sleepTask(task->controlBlock(), milliseconds);
#if TOURTOS_USE_HOST_RUNTIME
    task->waitWhileSuspended();
#endif
}

void Task::yield() noexcept {
    Task* task = current();
    if (task != nullptr) {
        auto& scheduler = Kernel::SystemKernel::instance().scheduler();
        scheduler.makeReady(task->controlBlock());
#if TOURTOS_USE_HOST_RUNTIME
        std::this_thread::yield();
#endif
        scheduler.makeRunning(task->controlBlock());
#if TOURTOS_USE_HOST_RUNTIME
        task->waitWhileSuspended();
#endif
        return;
    }

#if TOURTOS_USE_HOST_RUNTIME
    std::this_thread::yield();
#else
    Kernel::SystemKernel::instance().advanceTicks(1U);
#endif
}

Task* Task::current() noexcept {
    return g_current_task;
}

bool Task::keepRunning() noexcept {
    return !Kernel::SystemKernel::instance().stopRequested();
}

void Task::initializeControlBlock(const TaskConfig& config) noexcept {
    control_block_.id = g_next_task_id.fetch_add(1U);
    control_block_.name = name_;
    control_block_.priority = Kernel::Config::clampPriority(config.priority);
    control_block_.stack_size = Kernel::Config::clampTaskStackSize(config.stack_size);
    control_block_.quantum_ticks = Kernel::Config::clampQuantumTicks(config.quantum_ticks);
    control_block_.state = Kernel::TaskState::Suspended;
    control_block_.owner = this;
}

void Task::threadMain() noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    g_current_task = this;
    auto& scheduler = Kernel::SystemKernel::instance().scheduler();
    scheduler.makeRunning(control_block_);
    waitWhileSuspended();

    if (entry_) {
        entry_();
    }

    control_block_.state = Kernel::TaskState::Finished;
    finished_.store(true);
    g_current_task = nullptr;
#endif
}

void Task::waitWhileSuspended() noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    while (suspended_.load() && !Kernel::SystemKernel::instance().stopRequested()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
#endif
}

}  // namespace TouRTOS
