#pragma once

#include <chrono>
#include <cstdint>
#include <thread>

#include "TouRTOS/framework/TouRTOS.h"
#include "TouRTOS/kernel/SystemKernel.h"

void Setup();

inline TouRTOS::Application& TouApplication() noexcept {
    static TouRTOS::Application app;
    return app;
}

inline void TouDelayMs(std::uint32_t milliseconds) noexcept {
    TouRTOS::Task::sleep(milliseconds);
}

inline void TouYield() noexcept {
    TouRTOS::Task::yield();
}

inline void TouStopScheduler() noexcept {
    TouApplication().stop();
}

inline void TouStartScheduler() noexcept {
    static bool setup_called = false;

    TouApplication().start();
    if (!setup_called) {
        Setup();
        setup_called = true;
    }

    while (!TouRTOS::Kernel::SystemKernel::instance().stopRequested()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}
