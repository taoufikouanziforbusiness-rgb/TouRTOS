#pragma once

#include <chrono>

#include "TouRTOS/drivers/TargetConfig.h"

#if TOURTOS_USE_HOST_RUNTIME
#include <thread>
#endif

#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

class Application {
public:
    void start() noexcept {
        Kernel::SystemKernel::instance().startHostTick();
    }

    void stop() noexcept {
        Kernel::SystemKernel::instance().stopHostTick();
    }

    template <typename Rep, typename Period>
    void runFor(const std::chrono::duration<Rep, Period>& duration) noexcept {
        start();
#if TOURTOS_USE_HOST_RUNTIME
        std::this_thread::sleep_for(duration);
#else
        const auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
        if (milliseconds > 0) {
            Kernel::SystemKernel::instance().advanceTicks(static_cast<std::uint64_t>(milliseconds));
        }
#endif
        stop();
    }

    void tick(std::uint64_t ticks = 1U) noexcept {
        Kernel::SystemKernel::instance().advanceTicks(ticks);
    }
};

}  // namespace TouRTOS
