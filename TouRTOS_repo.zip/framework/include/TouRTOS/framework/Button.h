#pragma once

#include "TouRTOS/framework/DigitalPin.h"

namespace TouRTOS {

class Button {
public:
    explicit Button(std::uint32_t pin) noexcept : pin_(pin, Drivers::PinMode::InputPullup) {}

    [[nodiscard]] bool read() const noexcept {
        return pin_.read();
    }

private:
    DigitalPin pin_;
};

}  // namespace TouRTOS
