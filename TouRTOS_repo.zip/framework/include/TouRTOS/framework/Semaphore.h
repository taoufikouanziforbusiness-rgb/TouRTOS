#pragma once

#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <mutex>

#include "TouRTOS/kernel/Config.h"

namespace TouRTOS {

class CountingSemaphore {
public:
    CountingSemaphore(std::size_t initial_count, std::size_t max_count) noexcept;

    bool take(std::uint32_t timeout_ms = Kernel::Config::WaitForever) noexcept;
    bool tryTake() noexcept;
    void give() noexcept;
    [[nodiscard]] std::size_t count() const noexcept;

private:
    mutable std::mutex mutex_{};
    std::condition_variable cv_{};
    std::size_t count_{0U};
    std::size_t max_count_{0U};
};

class BinarySemaphore : public CountingSemaphore {
public:
    explicit BinarySemaphore(bool initially_available = false) noexcept
        : CountingSemaphore(initially_available ? 1U : 0U, 1U) {}
};

}  // namespace TouRTOS
