#pragma once

#include <cstdint>

#include "TouRTOS/kernel/SoftwareTimer.h"

namespace TouRTOS {

using TimerMode = Kernel::TimerMode;

class Timer {
public:
    using Callback = Kernel::SoftwareTimer::Callback;

    Timer() = default;

    template <typename Callable>
    Timer(const char* name, std::uint32_t period_ms, TimerMode mode, Callable callback) noexcept
        : timer_(name, period_ms, mode, Callback(std::move(callback))) {
        registerWithKernel();
    }

    void start() noexcept;
    void stop() noexcept;
    void restart() noexcept;

    [[nodiscard]] bool active() const noexcept;
    [[nodiscard]] const char* name() const noexcept;
    [[nodiscard]] std::uint32_t periodMilliseconds() const noexcept;

private:
    void registerWithKernel() noexcept;

    Kernel::SoftwareTimer timer_{};
};

}  // namespace TouRTOS
