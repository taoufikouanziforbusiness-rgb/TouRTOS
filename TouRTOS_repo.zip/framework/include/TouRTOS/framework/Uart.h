#pragma once

#include <cstdint>
#include <string_view>

#include "TouRTOS/drivers/Serial.h"

namespace TouRTOS {

class Uart {
public:
    Uart(std::uint8_t instance, std::uint32_t baud_rate) noexcept : instance_(instance), baud_rate_(baud_rate) {
        Drivers::openSerial(instance_, baud_rate_);
    }

    bool write(std::string_view text) noexcept {
        return Drivers::writeSerial(instance_, text.data(), text.size());
    }

private:
    std::uint8_t instance_{0U};
    std::uint32_t baud_rate_{0U};
};

}  // namespace TouRTOS
