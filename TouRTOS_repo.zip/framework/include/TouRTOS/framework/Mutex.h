#pragma once

#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <thread>

#include "TouRTOS/kernel/Config.h"

namespace TouRTOS {

class Mutex {
public:
    bool lock(std::uint32_t timeout_ms = Kernel::Config::WaitForever) noexcept;
    bool tryLock() noexcept;
    void unlock() noexcept;

private:
    std::mutex mutex_{};
    std::condition_variable cv_{};
    bool locked_{false};
    std::thread::id owner_{};
};

}  // namespace TouRTOS
