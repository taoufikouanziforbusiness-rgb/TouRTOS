#pragma once

#include "TouRTOS/framework/DigitalPin.h"

namespace TouRTOS {

class Led {
public:
    explicit Led(std::uint32_t pin) noexcept : pin_(pin, Drivers::PinMode::Output) {}

    void on() noexcept {
        pin_.high();
    }

    void off() noexcept {
        pin_.low();
    }

    void toggle() noexcept {
        pin_.toggle();
    }

private:
    DigitalPin pin_;
};

}  // namespace TouRTOS
