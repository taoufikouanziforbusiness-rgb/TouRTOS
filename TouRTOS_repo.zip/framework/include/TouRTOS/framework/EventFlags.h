#pragma once

#include <condition_variable>
#include <cstdint>
#include <mutex>

#include "TouRTOS/kernel/Config.h"

namespace TouRTOS {

class EventFlags {
public:
    void set(std::uint32_t mask) noexcept;
    void clear(std::uint32_t mask) noexcept;
    [[nodiscard]] std::uint32_t get() const noexcept;

    std::uint32_t waitAny(std::uint32_t mask, std::uint32_t timeout_ms = Kernel::Config::WaitForever, bool auto_clear = true) noexcept;
    std::uint32_t waitAll(std::uint32_t mask, std::uint32_t timeout_ms = Kernel::Config::WaitForever, bool auto_clear = true) noexcept;

private:
    mutable std::mutex mutex_{};
    std::condition_variable cv_{};
    std::uint32_t flags_{0U};
};

}  // namespace TouRTOS
