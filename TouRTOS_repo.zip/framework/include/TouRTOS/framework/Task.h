#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "TouRTOS/drivers/TargetConfig.h"

#if TOURTOS_USE_HOST_RUNTIME
#include <thread>
#endif

#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/InplaceFunction.h"
#include "TouRTOS/kernel/TaskControlBlock.h"

namespace TouRTOS {

class Task;

class TaskHandle {
public:
    [[nodiscard]] Task* get() const noexcept {
        return task_;
    }

private:
    friend class Task;
    Task* task_{nullptr};
};

struct TaskConfig {
    std::size_t priority{1U};
    std::size_t stack_size{Kernel::Config::DefaultTaskStackSize};
    std::size_t quantum_ticks{Kernel::Config::DefaultRoundRobinQuantumTicks};
    bool auto_start{false};
};

class Task {
public:
    using Entry = Kernel::InplaceFunction<Kernel::Config::TaskCallableStorage, void()>;

    Task() = default;

    template <typename Callable>
    Task(const char* name, Callable entry, TaskConfig config = {}) noexcept
        : name_(name), entry_(std::move(entry)) {
        initializeControlBlock(config);
    }

    ~Task() noexcept;

    Task(const Task&) = delete;
    Task& operator=(const Task&) = delete;
    Task(Task&&) = delete;
    Task& operator=(Task&&) = delete;

    void start() noexcept;
    void join() noexcept;
    [[nodiscard]] bool joinable() const noexcept;

    void suspend() noexcept;
    void resume() noexcept;
    [[nodiscard]] bool stopRequested() const noexcept;

    void setPriority(std::size_t priority) noexcept;
    void setStackSize(std::size_t stack_size) noexcept;
    void setHandle(TaskHandle* handle) noexcept;
    void setName(const char* name) noexcept;

    void Priority(std::size_t priority) noexcept {
        setPriority(priority);
    }

    void StackSize(std::size_t stack_size) noexcept {
        setStackSize(stack_size);
    }

    void Handle(TaskHandle* handle) noexcept {
        setHandle(handle);
    }

    void Handle(TaskHandle& handle) noexcept {
        setHandle(&handle);
    }

    void Start() noexcept {
        start();
    }

    void Suspend() noexcept {
        suspend();
    }

    void Resume() noexcept {
        resume();
    }

    [[nodiscard]] const char* name() const noexcept;
    [[nodiscard]] std::size_t priority() const noexcept;
    [[nodiscard]] Kernel::TaskControlBlock& controlBlock() noexcept;
    [[nodiscard]] const Kernel::TaskControlBlock& controlBlock() const noexcept;

    static void sleep(std::uint32_t milliseconds) noexcept;
    static void yield() noexcept;
    [[nodiscard]] static Task* current() noexcept;
    [[nodiscard]] static bool keepRunning() noexcept;

private:
    void initializeControlBlock(const TaskConfig& config) noexcept;
    void threadMain() noexcept;
    void waitWhileSuspended() noexcept;

    const char* name_{"task"};
    Entry entry_{};
    Kernel::TaskControlBlock control_block_{};
#if TOURTOS_USE_HOST_RUNTIME
    std::thread thread_{};
#endif
    std::atomic<bool> started_{false};
    std::atomic<bool> suspended_{false};
    std::atomic<bool> finished_{false};
};

}  // namespace TouRTOS
