#pragma once

#include <cstdint>

#include "TouRTOS/drivers/InputOutput.h"

namespace TouRTOS {

class DigitalPin {
public:
    DigitalPin(std::uint32_t pin, Drivers::PinMode mode) noexcept : pin_(pin), mode_(mode) {
        Drivers::configurePin(pin_, mode_);
    }

    void high() noexcept {
        Drivers::writePin(pin_, Drivers::PinState::High);
    }

    void low() noexcept {
        Drivers::writePin(pin_, Drivers::PinState::Low);
    }

    void toggle() noexcept {
        Drivers::togglePin(pin_);
    }

    [[nodiscard]] bool read() const noexcept {
        return Drivers::readPin(pin_) == Drivers::PinState::High;
    }

    [[nodiscard]] std::uint32_t number() const noexcept {
        return pin_;
    }

private:
    std::uint32_t pin_{0U};
    Drivers::PinMode mode_{Drivers::PinMode::Input};
};

}  // namespace TouRTOS
