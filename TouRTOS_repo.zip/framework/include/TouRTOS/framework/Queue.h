#pragma once

#include <array>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <mutex>

#include "TouRTOS/framework/Task.h"
#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/SystemKernel.h"

namespace TouRTOS {

template <typename T, std::size_t Capacity>
class Queue {
public:
    bool send(const T& value, std::uint32_t timeout_ms = Kernel::Config::WaitForever) noexcept {
        auto& kernel = Kernel::SystemKernel::instance();
        Task* task = Task::current();
        const auto deadline = timeoutDeadline(timeout_ms);

        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ == Capacity) {
            if (!beforeWait(kernel, task, deadline)) {
                return false;
            }
            not_full_cv_.wait_for(lock, std::chrono::milliseconds(1));
        }

        buffer_[tail_] = value;
        tail_ = (tail_ + 1U) % Capacity;
        ++count_;
        if (task != nullptr) {
            kernel.scheduler().makeReady(task->controlBlock());
        }
        lock.unlock();
        not_empty_cv_.notify_one();
        return true;
    }

    bool receive(T& value, std::uint32_t timeout_ms = Kernel::Config::WaitForever) noexcept {
        auto& kernel = Kernel::SystemKernel::instance();
        Task* task = Task::current();
        const auto deadline = timeoutDeadline(timeout_ms);

        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ == 0U) {
            if (!beforeWait(kernel, task, deadline)) {
                return false;
            }
            not_empty_cv_.wait_for(lock, std::chrono::milliseconds(1));
        }

        value = buffer_[head_];
        head_ = (head_ + 1U) % Capacity;
        --count_;
        if (task != nullptr) {
            kernel.scheduler().makeReady(task->controlBlock());
        }
        lock.unlock();
        not_full_cv_.notify_one();
        return true;
    }

    [[nodiscard]] bool trySend(const T& value) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        if (count_ == Capacity) {
            return false;
        }
        buffer_[tail_] = value;
        tail_ = (tail_ + 1U) % Capacity;
        ++count_;
        not_empty_cv_.notify_one();
        return true;
    }

    [[nodiscard]] bool tryReceive(T& value) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        if (count_ == 0U) {
            return false;
        }
        value = buffer_[head_];
        head_ = (head_ + 1U) % Capacity;
        --count_;
        not_full_cv_.notify_one();
        return true;
    }

    [[nodiscard]] std::size_t size() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return count_;
    }

    [[nodiscard]] constexpr std::size_t capacity() const noexcept {
        return Capacity;
    }

private:
    [[nodiscard]] static Kernel::Tick timeoutDeadline(std::uint32_t timeout_ms) noexcept {
        if (timeout_ms == Kernel::Config::WaitForever) {
            return 0U;
        }
        auto& tick_engine = Kernel::SystemKernel::instance().tickEngine();
        return tick_engine.now() + tick_engine.msToTicks(timeout_ms);
    }

    [[nodiscard]] static bool beforeWait(Kernel::SystemKernel& kernel, Task* task, Kernel::Tick deadline) noexcept {
        if (task != nullptr) {
            kernel.scheduler().blockTask(task->controlBlock(), deadline);
        }

        const bool timed_out = deadline != 0U && kernel.tickEngine().now() >= deadline;
        if (timed_out || kernel.stopRequested()) {
            if (task != nullptr) {
                kernel.scheduler().makeReady(task->controlBlock());
            }
            return false;
        }
        return true;
    }

    mutable std::mutex mutex_{};
    std::condition_variable not_empty_cv_{};
    std::condition_variable not_full_cv_{};
    std::array<T, Capacity> buffer_{};
    std::size_t head_{0U};
    std::size_t tail_{0U};
    std::size_t count_{0U};
};

}  // namespace TouRTOS
