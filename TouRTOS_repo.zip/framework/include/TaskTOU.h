#pragma once

#include "TouRTOS.h"

using TaskTOU = TouRTOS::Task;
using TaskTou = TouRTOS::Task;
using TaskTOUHandle = TouRTOS::TaskHandle;
using TaskTouHandle = TouRTOS::TaskHandle;
