#pragma once

#include <string>
#include <vector>

#include "TouRTOS/language/Ast.h"
#include "TouRTOS/language/Tokenizer.h"

namespace TouRTOS::Language {

struct ParseResult {
    Program program{};
    std::vector<std::string> errors{};

    [[nodiscard]] bool ok() const noexcept {
        return errors.empty();
    }
};

class Parser {
public:
    [[nodiscard]] ParseResult parse(const std::string& source) const;

private:
    [[nodiscard]] static bool isStandaloneBeginLine(const TokenLine& line) noexcept;
    [[nodiscard]] static bool isStandaloneEndLine(const TokenLine& line) noexcept;
    [[nodiscard]] static bool isMetadataAssignment(const TokenLine& line) noexcept;
    [[nodiscard]] static std::string trim(const std::string& text);
};

}  // namespace TouRTOS::Language
