#pragma once

#include <string>
#include <vector>

#include "TouRTOS/language/Token.h"

namespace TouRTOS::Language {

class Tokenizer {
public:
    [[nodiscard]] std::vector<TokenLine> tokenize(const std::string& source) const;
};

}  // namespace TouRTOS::Language
