#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace TouRTOS::Language {

enum class TokenType {
    Identifier,
    Number,
    KeywordTask,
    KeywordTimer,
    KeywordBegin,
    KeywordEnd,
    KeywordPriority,
    KeywordHandle,
    LeftParen,
    RightParen,
    Comma,
    Dot,
    Equal,
    Semicolon,
    Unknown
};

struct Token {
    TokenType type{TokenType::Unknown};
    std::string lexeme{};
    std::size_t line{0U};
    std::size_t column{0U};
};

struct TokenLine {
    std::size_t line_number{0U};
    std::string raw_text{};
    std::vector<Token> tokens{};
};

}  // namespace TouRTOS::Language
