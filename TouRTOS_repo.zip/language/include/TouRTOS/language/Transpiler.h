#pragma once

#include <string>

#include "TouRTOS/language/Ast.h"

namespace TouRTOS::Language {

class Transpiler {
public:
    [[nodiscard]] std::string transpile(const Program& program, const std::string& source_name) const;
};

}  // namespace TouRTOS::Language
