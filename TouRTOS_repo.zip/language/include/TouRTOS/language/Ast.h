#pragma once

#include <optional>
#include <string>
#include <vector>

namespace TouRTOS::Language {

struct MetadataAssignment {
    std::string object_name{};
    std::string field{};
    std::string value{};
    bool method_style{false};
};

struct TaskNode {
    std::string name{};
    std::string args{};
    std::string body{};
    std::optional<std::string> inline_priority{};
    std::optional<std::string> inline_handle{};
    bool inside_setup{false};
};

struct TimerNode {
    std::string name{};
    std::string period_expression{};
    std::string mode_expression{};
    std::string body{};
    bool inside_setup{false};
};

struct Program {
    std::vector<std::string> passthrough_lines{};
    std::vector<std::string> setup_body_lines{};
    std::vector<TaskNode> tasks{};
    std::vector<TimerNode> timers{};
    std::vector<MetadataAssignment> assignments{};
    bool has_setup_block{false};
};

}  // namespace TouRTOS::Language
