#include "TouRTOS/language/Transpiler.h"

#include <regex>
#include <sstream>

namespace TouRTOS::Language {

namespace {

std::string replaceKernelCalls(const std::string& body) {
    std::string translated = std::regex_replace(body, std::regex(R"(\bsleep\s*\()"), "Task::sleep(");
    translated = std::regex_replace(translated, std::regex(R"(\byield\s*\()"), "Task::yield(");
    return translated;
}

std::string translateTimerMode(const std::string& expression) {
    if (expression == "Periodic" || expression == "periodic") {
        return "TimerMode::Periodic";
    }
    if (expression == "OneShot" || expression == "oneshot" || expression == "one_shot") {
        return "TimerMode::OneShot";
    }
    if (expression.find("TimerMode::") != std::string::npos) {
        return expression;
    }
    return expression;
}

std::string indent(const std::string& text, const std::string& prefix) {
    std::ostringstream stream;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        stream << prefix << line << '\n';
    }
    return stream.str();
}

std::string ltrim(const std::string& text) {
    const auto start = text.find_first_not_of(" \t\r");
    return start == std::string::npos ? std::string{} : text.substr(start);
}

bool shouldStaticizeSetupLine(const std::string& line) {
    const std::string trimmed = ltrim(line);
    return trimmed.rfind("TaskHandle ", 0U) == 0U
        || trimmed.rfind("TaskTouHandle ", 0U) == 0U
        || trimmed.rfind("TaskTOUHandle ", 0U) == 0U;
}

std::string staticizeSetupLine(const std::string& line) {
    const auto first_non_space = line.find_first_not_of(" \t\r");
    if (first_non_space == std::string::npos) {
        return line;
    }
    return line.substr(0U, first_non_space) + "static " + line.substr(first_non_space);
}

bool isTaskMarker(const std::string& line) {
    return line.rfind("__TOURTOS_TASK_", 0U) == 0U && line.size() > 16U;
}

std::size_t taskMarkerIndex(const std::string& line) {
    const auto suffix_start = std::string("__TOURTOS_TASK_").size();
    const auto suffix_end = line.find("__", suffix_start);
    return static_cast<std::size_t>(std::stoul(line.substr(suffix_start, suffix_end - suffix_start)));
}

const MetadataAssignment* findAssignment(
    const std::vector<MetadataAssignment>& assignments,
    const std::string& object_name,
    const std::string& field_name,
    bool method_style
) {
    for (auto it = assignments.rbegin(); it != assignments.rend(); ++it) {
        if (it->object_name == object_name && it->field == field_name && it->method_style == method_style) {
            return &(*it);
        }
    }
    return nullptr;
}

void emitTaskConfiguration(
    std::ostringstream& output,
    const TaskNode& task,
    const std::vector<MetadataAssignment>& assignments,
    bool method_style
) {
    const auto* priority_assignment = findAssignment(assignments, task.name, "priority", method_style);
    const auto* handle_assignment = findAssignment(assignments, task.name, "handle", method_style);
    const auto* stack_assignment = findAssignment(assignments, task.name, "stacksize", method_style);

    const std::string priority_value = priority_assignment != nullptr
        ? priority_assignment->value
        : task.inline_priority.value_or("");
    const std::string handle_value = handle_assignment != nullptr
        ? handle_assignment->value
        : task.inline_handle.value_or("");
    const std::string stack_value = stack_assignment != nullptr ? stack_assignment->value : "";

    if (!priority_value.empty()) {
        output << "    " << task.name << ".Priority(" << priority_value << ");\n";
    }
    if (!stack_value.empty()) {
        output << "    " << task.name << ".StackSize(" << stack_value << ");\n";
    }
    if (!handle_value.empty()) {
        output << "    " << task.name << ".Handle(&" << handle_value << ");\n";
    }
}

}  // namespace

std::string Transpiler::transpile(const Program& program, const std::string& source_name) const {
    std::ostringstream output;
    output << "// Generated from " << source_name << '\n';
    output << "#include <TouRTOS.h>\n\n";

    for (const auto& line : program.passthrough_lines) {
        output << line << '\n';
    }
    if (!program.passthrough_lines.empty()) {
        output << '\n';
    }

    output << "using namespace TouRTOS;\n\n";

    if (!program.has_setup_block) {
        for (const auto& task : program.tasks) {
            output << "Task " << task.name << "(\"" << task.name << "\", []() {\n";
            output << indent(replaceKernelCalls(task.body), "    ");
            output << "});\n\n";
        }

        for (const auto& timer : program.timers) {
            output << "Timer " << timer.name << "(\"" << timer.name << "\", "
                   << timer.period_expression << ", "
                   << translateTimerMode(timer.mode_expression) << ", []() {\n";
            output << indent(replaceKernelCalls(timer.body), "    ");
            output << "});\n\n";
        }

        output << "void Setup() {\n";
        for (const auto& task : program.tasks) {
            emitTaskConfiguration(output, task, program.assignments, false);
            output << "    " << task.name << ".start();\n";
        }

        for (const auto& timer : program.timers) {
            output << "    " << timer.name << ".start();\n";
        }
        output << "}\n";
        return output.str();
    }

    output << "void Setup() {\n";
    for (const auto& line : program.setup_body_lines) {
        if (isTaskMarker(line)) {
            const auto& task = program.tasks[taskMarkerIndex(line)];
            output << "    static Task " << task.name << "(\"" << task.name << "\", [=]() {\n";
            output << indent(replaceKernelCalls(task.body), "        ");
            output << "    });\n";
            continue;
        }

        output << (shouldStaticizeSetupLine(line) ? staticizeSetupLine(line) : line) << '\n';
    }

    if (!program.setup_body_lines.empty()) {
        output << '\n';
    }

    for (const auto& task : program.tasks) {
        if (!task.inside_setup) {
            continue;
        }
        emitTaskConfiguration(output, task, program.assignments, false);
        output << "    " << task.name << ".start();\n";
    }

    for (const auto& timer : program.timers) {
        if (!timer.inside_setup) {
            continue;
        }
        output << "    " << timer.name << ".start();\n";
    }

    output << "}\n";
    return output.str();
}

}  // namespace TouRTOS::Language
