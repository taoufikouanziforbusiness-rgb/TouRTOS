#include "TouRTOS/language/Tokenizer.h"

#include <cctype>

namespace TouRTOS::Language {

namespace {

TokenType keywordType(const std::string& word) {
    if (word == "task") {
        return TokenType::KeywordTask;
    }
    if (word == "timer") {
        return TokenType::KeywordTimer;
    }
    if (word == "begin") {
        return TokenType::KeywordBegin;
    }
    if (word == "end") {
        return TokenType::KeywordEnd;
    }
    if (word == "priority") {
        return TokenType::KeywordPriority;
    }
    if (word == "handle") {
        return TokenType::KeywordHandle;
    }
    return TokenType::Identifier;
}

}  // namespace

std::vector<TokenLine> Tokenizer::tokenize(const std::string& source) const {
    std::vector<TokenLine> lines;
    std::size_t line_number = 1U;
    std::size_t cursor = 0U;

    while (cursor <= source.size()) {
        const std::size_t line_end = source.find('\n', cursor);
        const bool found_newline = line_end != std::string::npos;
        const std::size_t slice_end = found_newline ? line_end : source.size();
        std::string raw_line = source.substr(cursor, slice_end - cursor);

        TokenLine line;
        line.line_number = line_number;
        line.raw_text = raw_line;

        for (std::size_t column = 0U; column < raw_line.size();) {
            const char current = raw_line[column];
            if (std::isspace(static_cast<unsigned char>(current)) != 0) {
                ++column;
                continue;
            }

            if (std::isalpha(static_cast<unsigned char>(current)) != 0 || current == '_') {
                std::size_t end = column + 1U;
                while (end < raw_line.size()) {
                    const char next = raw_line[end];
                    if (std::isalnum(static_cast<unsigned char>(next)) == 0 && next != '_') {
                        break;
                    }
                    ++end;
                }
                const std::string word = raw_line.substr(column, end - column);
                line.tokens.push_back(Token{keywordType(word), word, line_number, column + 1U});
                column = end;
                continue;
            }

            if (std::isdigit(static_cast<unsigned char>(current)) != 0) {
                std::size_t end = column + 1U;
                while (end < raw_line.size() && std::isdigit(static_cast<unsigned char>(raw_line[end])) != 0) {
                    ++end;
                }
                const std::string word = raw_line.substr(column, end - column);
                line.tokens.push_back(Token{TokenType::Number, word, line_number, column + 1U});
                column = end;
                continue;
            }

            Token token;
            token.lexeme = std::string(1U, current);
            token.line = line_number;
            token.column = column + 1U;

            switch (current) {
                case '(':
                    token.type = TokenType::LeftParen;
                    break;
                case ')':
                    token.type = TokenType::RightParen;
                    break;
                case ',':
                    token.type = TokenType::Comma;
                    break;
                case '.':
                    token.type = TokenType::Dot;
                    break;
                case '=':
                    token.type = TokenType::Equal;
                    break;
                case ';':
                    token.type = TokenType::Semicolon;
                    break;
                default:
                    token.type = TokenType::Unknown;
                    break;
            }
            line.tokens.push_back(token);
            ++column;
        }

        lines.push_back(std::move(line));

        if (!found_newline) {
            break;
        }
        cursor = slice_end + 1U;
        ++line_number;
    }

    return lines;
}

}  // namespace TouRTOS::Language
