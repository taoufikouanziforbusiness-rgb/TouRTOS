#include "TouRTOS/language/Parser.h"

#include <algorithm>
#include <cctype>
#include <sstream>

namespace TouRTOS::Language {

namespace {

std::string joinLexemes(
    const std::vector<Token>& tokens,
    std::size_t start_index,
    std::size_t end_index,
    const char* separator = ""
) {
    std::ostringstream stream;
    for (std::size_t index = start_index; index < end_index; ++index) {
        if (index != start_index) {
            stream << separator;
        }
        stream << tokens[index].lexeme;
    }
    return stream.str();
}

std::string lowercase(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char character) {
        return static_cast<char>(std::tolower(character));
    });
    return value;
}

bool startsWith(const std::string& text, const std::string& prefix) {
    return text.rfind(prefix, 0U) == 0U;
}

bool isTaskHeaderLine(const TokenLine& line) {
    if (line.tokens.empty()) {
        return false;
    }

    const auto& first = line.tokens.front();
    return first.type == TokenType::KeywordTask
        || (first.type == TokenType::Identifier && (first.lexeme == "TaskTou" || first.lexeme == "TaskTOU"));
}

bool isSetupHeaderLineText(const std::string& trimmed) {
    return trimmed == "Setup()"
        || trimmed == "Setup() {"
        || trimmed == "Setup(){"
        || trimmed == "void Setup()"
        || trimmed == "void Setup() {"
        || trimmed == "void Setup(){";
}

bool isMethodStyleMetadataLine(const TokenLine& line) {
    return line.tokens.size() >= 7U
        && line.tokens[0].type == TokenType::Identifier
        && line.tokens[1].type == TokenType::Dot
        && (line.tokens[2].type == TokenType::Identifier
            || line.tokens[2].type == TokenType::KeywordPriority
            || line.tokens[2].type == TokenType::KeywordHandle)
        && line.tokens[3].type == TokenType::LeftParen
        && line.tokens[line.tokens.size() - 2U].type == TokenType::RightParen
        && line.tokens.back().type == TokenType::Semicolon;
}

std::string normalizeFieldName(const std::string& value) {
    const std::string lower = lowercase(value);
    if (lower == "priority") {
        return "priority";
    }
    if (lower == "handle") {
        return "handle";
    }
    if (lower == "stacksize") {
        return "stacksize";
    }
    return lower;
}

std::size_t countCharacter(const std::string& text, char value) {
    return static_cast<std::size_t>(std::count(text.begin(), text.end(), value));
}

}  // namespace

ParseResult Parser::parse(const std::string& source) const {
    ParseResult result;
    const auto lines = Tokenizer{}.tokenize(source);

    auto parseTask = [&](std::size_t& index, bool inside_setup) -> bool {
        const auto& header_line = lines[index];
        if (header_line.tokens.size() < 4U) {
            result.errors.push_back("Malformed task header on line " + std::to_string(header_line.line_number));
            return false;
        }

        TaskNode task;
        task.name = header_line.tokens[1].lexeme;
        task.inside_setup = inside_setup;

        std::size_t left_paren_index = 2U;
        std::size_t right_paren_index = left_paren_index;
        while (right_paren_index < header_line.tokens.size()
               && header_line.tokens[right_paren_index].type != TokenType::RightParen) {
            ++right_paren_index;
        }
        if (right_paren_index >= header_line.tokens.size()) {
            result.errors.push_back("Task " + task.name + " is missing a closing parenthesis");
            return false;
        }

        task.args = joinLexemes(header_line.tokens, left_paren_index + 1U, right_paren_index);

        bool begin_found = header_line.tokens.back().type == TokenType::KeywordBegin;
        if (!begin_found) {
            std::size_t begin_index = index + 1U;
            while (begin_index < lines.size() && trim(lines[begin_index].raw_text).empty()) {
                ++begin_index;
            }
            if (begin_index >= lines.size() || !isStandaloneBeginLine(lines[begin_index])) {
                result.errors.push_back("Task " + task.name + " must terminate with begin");
                return false;
            }
            index = begin_index;
        }

        std::ostringstream body_stream;
        ++index;
        while (index < lines.size() && !isStandaloneEndLine(lines[index])) {
            const std::string trimmed_line = trim(lines[index].raw_text);
            if (!inside_setup && startsWith(trimmed_line, "priority ")) {
                task.inline_priority = trim(trimmed_line.substr(9U, trimmed_line.size() - 10U));
            } else if (!inside_setup && startsWith(trimmed_line, "handle ")) {
                task.inline_handle = trim(trimmed_line.substr(7U, trimmed_line.size() - 8U));
            } else {
                body_stream << lines[index].raw_text << '\n';
            }
            ++index;
        }

        if (index >= lines.size()) {
            result.errors.push_back("Task " + task.name + " is missing end");
            return false;
        }

        task.body = body_stream.str();
        result.program.tasks.push_back(std::move(task));
        return true;
    };

    auto parseSetupBlock = [&](std::size_t& index) -> bool {
        result.program.has_setup_block = true;

        std::string current_line = trim(lines[index].raw_text);
        bool opening_brace_found = current_line.find('{') != std::string::npos;
        if (!opening_brace_found) {
            ++index;
            while (index < lines.size() && trim(lines[index].raw_text).empty()) {
                ++index;
            }
            if (index >= lines.size() || trim(lines[index].raw_text) != "{") {
                result.errors.push_back("Setup() must be followed by an opening brace");
                return false;
            }
        }

        int brace_depth = 1;
        ++index;

        while (index < lines.size()) {
            const std::string trimmed_line = trim(lines[index].raw_text);
            if (brace_depth == 1 && trimmed_line == "}") {
                return true;
            }

            if (isTaskHeaderLine(lines[index])) {
                const std::size_t task_index = result.program.tasks.size();
                if (!parseTask(index, true)) {
                    return false;
                }
                result.program.setup_body_lines.push_back("__TOURTOS_TASK_" + std::to_string(task_index) + "__");
                ++index;
                continue;
            }

            result.program.setup_body_lines.push_back(lines[index].raw_text);
            brace_depth += static_cast<int>(countCharacter(lines[index].raw_text, '{'));
            brace_depth -= static_cast<int>(countCharacter(lines[index].raw_text, '}'));
            ++index;
        }

        result.errors.push_back("Setup() is missing a closing brace");
        return false;
    };

    for (std::size_t index = 0U; index < lines.size(); ++index) {
        const auto& line = lines[index];
        const std::string trimmed_line = trim(line.raw_text);

        if (line.tokens.empty()) {
            if (result.program.has_setup_block) {
                result.program.setup_body_lines.push_back(line.raw_text);
            }
            continue;
        }

        if (isSetupHeaderLineText(trimmed_line)) {
            if (!parseSetupBlock(index)) {
                break;
            }
            continue;
        }

        const auto first = line.tokens.front().type;
        if (isTaskHeaderLine(line)) {
            if (!parseTask(index, false)) {
                break;
            }
            continue;
        }

        if (first == TokenType::KeywordTimer) {
            if (line.tokens.size() < 7U) {
                result.errors.push_back("Malformed timer header on line " + std::to_string(line.line_number));
                continue;
            }

            TimerNode timer;
            timer.name = line.tokens[1].lexeme;

            std::size_t left_paren_index = 2U;
            std::size_t comma_index = left_paren_index;
            std::size_t right_paren_index = left_paren_index;
            while (right_paren_index < line.tokens.size() && line.tokens[right_paren_index].type != TokenType::RightParen) {
                if (line.tokens[right_paren_index].type == TokenType::Comma && comma_index == left_paren_index) {
                    comma_index = right_paren_index;
                }
                ++right_paren_index;
            }

            if (comma_index == left_paren_index || right_paren_index >= line.tokens.size()) {
                result.errors.push_back("Timer " + timer.name + " requires period and mode");
                continue;
            }

            timer.period_expression = joinLexemes(line.tokens, left_paren_index + 1U, comma_index);
            timer.mode_expression = joinLexemes(line.tokens, comma_index + 1U, right_paren_index);
            if (line.tokens.back().type != TokenType::KeywordBegin) {
                result.errors.push_back("Timer " + timer.name + " must terminate with begin");
                continue;
            }

            std::ostringstream body_stream;
            ++index;
            while (index < lines.size() && !isStandaloneEndLine(lines[index])) {
                body_stream << lines[index].raw_text << '\n';
                ++index;
            }

            if (index >= lines.size()) {
                result.errors.push_back("Timer " + timer.name + " is missing end");
                continue;
            }

            timer.body = body_stream.str();
            result.program.timers.push_back(std::move(timer));
            continue;
        }

        if (isMetadataAssignment(line)) {
            MetadataAssignment assignment;
            assignment.object_name = line.tokens[0].lexeme;
            assignment.field = normalizeFieldName(line.tokens[2].lexeme);
            assignment.value = joinLexemes(line.tokens, 4U, line.tokens.size() - 1U);
            assignment.method_style = false;
            result.program.assignments.push_back(std::move(assignment));
            continue;
        }

        if (isMethodStyleMetadataLine(line)) {
            MetadataAssignment assignment;
            assignment.object_name = line.tokens[0].lexeme;
            assignment.field = normalizeFieldName(line.tokens[2].lexeme);
            assignment.value = joinLexemes(line.tokens, 4U, line.tokens.size() - 2U);
            assignment.method_style = true;
            result.program.assignments.push_back(std::move(assignment));
            if (result.program.has_setup_block) {
                result.program.setup_body_lines.push_back(line.raw_text);
            }
            continue;
        }

        result.program.passthrough_lines.push_back(line.raw_text);
    }

    return result;
}

bool Parser::isStandaloneEndLine(const TokenLine& line) noexcept {
    return line.tokens.size() == 1U && line.tokens.front().type == TokenType::KeywordEnd;
}

bool Parser::isStandaloneBeginLine(const TokenLine& line) noexcept {
    return line.tokens.size() == 1U && line.tokens.front().type == TokenType::KeywordBegin;
}

bool Parser::isMetadataAssignment(const TokenLine& line) noexcept {
    return line.tokens.size() >= 6U
        && line.tokens[0].type == TokenType::Identifier
        && line.tokens[1].type == TokenType::Dot
        && (line.tokens[2].type == TokenType::Identifier
            || line.tokens[2].type == TokenType::KeywordPriority
            || line.tokens[2].type == TokenType::KeywordHandle)
        && line.tokens[3].type == TokenType::Equal
        && line.tokens.back().type == TokenType::Semicolon;
}

std::string Parser::trim(const std::string& text) {
    const auto start = text.find_first_not_of(" \t\r");
    if (start == std::string::npos) {
        return {};
    }
    const auto end = text.find_last_not_of(" \t\r");
    return text.substr(start, end - start + 1U);
}

}  // namespace TouRTOS::Language
