function(tourtos_apply_project_options target_name)
    target_compile_options(
        ${target_name}
        INTERFACE
            -Wall
            -Wextra
            -Wpedantic
            -Wconversion
            -Wshadow
            -Wnon-virtual-dtor
            -Wold-style-cast
            -Woverloaded-virtual
            -Wnull-dereference
            -Wdouble-promotion
            -Wformat=2
    )

    target_compile_definitions(
        ${target_name}
        INTERFACE
            TOURTOS_NO_EXCEPTIONS=1
            TOURTOS_NO_RTTI=1
    )
endfunction()
