set(TOURTOS_SUPPORTED_TARGET_PLATFORMS host avr stm32 pic)
set(TOURTOS_AVR_SUPPORTED_MCUS atmega328p atmega2560 attiny85)
set(TOURTOS_STM32_SUPPORTED_MCUS stm32f103c8 stm32f401cc stm32h743zi)
set(TOURTOS_PIC_SUPPORTED_MCUS pic16f877a pic18f4550 pic18f46k22)

set(TOURTOS_TARGET_PLATFORM "host" CACHE STRING "TouRTOS target platform")
set_property(CACHE TOURTOS_TARGET_PLATFORM PROPERTY STRINGS ${TOURTOS_SUPPORTED_TARGET_PLATFORMS})

set(TOURTOS_AVR_MCU "atmega328p" CACHE STRING "TouRTOS AVR MCU profile")
set_property(CACHE TOURTOS_AVR_MCU PROPERTY STRINGS ${TOURTOS_AVR_SUPPORTED_MCUS})

set(TOURTOS_STM32_MCU "stm32f103c8" CACHE STRING "TouRTOS STM32 MCU profile")
set_property(CACHE TOURTOS_STM32_MCU PROPERTY STRINGS ${TOURTOS_STM32_SUPPORTED_MCUS})

set(TOURTOS_PIC_MCU "pic16f877a" CACHE STRING "TouRTOS PIC MCU profile")
set_property(CACHE TOURTOS_PIC_MCU PROPERTY STRINGS ${TOURTOS_PIC_SUPPORTED_MCUS})

function(tourtos_validate_cache_choice variable_name)
    set(allowed_values ${ARGN})
    list(FIND allowed_values "${${variable_name}}" selected_index)
    if(selected_index EQUAL -1)
        string(JOIN ", " allowed_values_text ${allowed_values})
        message(
            FATAL_ERROR
            "${variable_name} must be one of: ${allowed_values_text}. Current value: ${${variable_name}}"
        )
    endif()
endfunction()

function(tourtos_selected_mcu out_variable)
    if(TOURTOS_TARGET_PLATFORM STREQUAL "host")
        set(selected_mcu "native-host")
    elseif(TOURTOS_TARGET_PLATFORM STREQUAL "avr")
        set(selected_mcu "${TOURTOS_AVR_MCU}")
    elseif(TOURTOS_TARGET_PLATFORM STREQUAL "stm32")
        set(selected_mcu "${TOURTOS_STM32_MCU}")
    elseif(TOURTOS_TARGET_PLATFORM STREQUAL "pic")
        set(selected_mcu "${TOURTOS_PIC_MCU}")
    else()
        message(FATAL_ERROR "Unsupported TouRTOS target platform: ${TOURTOS_TARGET_PLATFORM}")
    endif()

    set(${out_variable} "${selected_mcu}" PARENT_SCOPE)
endfunction()

function(tourtos_enable_target_compile_definitions target_name)
    if(TOURTOS_TARGET_PLATFORM STREQUAL "host")
        set(host_runtime 1)
    else()
        set(host_runtime 0)
    endif()

    tourtos_selected_mcu(selected_mcu)

    target_compile_definitions(
        ${target_name}
        INTERFACE
            TOURTOS_USE_HOST_RUNTIME=${host_runtime}
            TOURTOS_TARGET_PLATFORM_NAME=\"${TOURTOS_TARGET_PLATFORM}\"
            TOURTOS_TARGET_MCU_NAME=\"${selected_mcu}\"
    )
endfunction()

function(tourtos_apply_port_profile target_name family_name mcu_name)
    string(TOUPPER "${family_name}" family_macro)
    string(TOUPPER "${mcu_name}" mcu_macro)
    string(REPLACE "-" "_" mcu_macro "${mcu_macro}")
    string(REPLACE "." "_" mcu_macro "${mcu_macro}")

    target_compile_definitions(
        ${target_name}
        PUBLIC
            TOURTOS_TARGET_PLATFORM_${family_macro}=1
            TOURTOS_${family_macro}_MCU_${mcu_macro}=1
    )
endfunction()

tourtos_validate_cache_choice(TOURTOS_TARGET_PLATFORM ${TOURTOS_SUPPORTED_TARGET_PLATFORMS})
tourtos_validate_cache_choice(TOURTOS_AVR_MCU ${TOURTOS_AVR_SUPPORTED_MCUS})
tourtos_validate_cache_choice(TOURTOS_STM32_MCU ${TOURTOS_STM32_SUPPORTED_MCUS})
tourtos_validate_cache_choice(TOURTOS_PIC_MCU ${TOURTOS_PIC_SUPPORTED_MCUS})
