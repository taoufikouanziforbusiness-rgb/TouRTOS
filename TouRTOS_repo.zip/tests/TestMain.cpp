#include <atomic>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>
#include <string_view>
#include <thread>

#include <TouRTOS.h>
#include "TouRTOS/drivers/TargetConfig.h"
#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/Scheduler.h"
#include "TouRTOS/kernel/SystemKernel.h"
#include "TouRTOS/kernel/TickEngine.h"
#include "TouRTOS/language/Parser.h"
#include "TouRTOS/language/Transpiler.h"
#include "TouRTOS/ports/avr/Platform.h"
#include "TouRTOS/ports/host/Platform.h"
#include "TouRTOS/ports/pic/Platform.h"
#include "TouRTOS/ports/stm32/Platform.h"

namespace {

struct TestContext {
    int passed{0};
    int failed{0};

    void require(bool condition, const std::string& message) {
        if (condition) {
            ++passed;
            return;
        }
        ++failed;
        std::cerr << "[FAIL] " << message << '\n';
    }
};

void testTickEngine(TestContext& ctx) {
    TouRTOS::Kernel::TickEngine tick_engine;
    tick_engine.advance(5);
    ctx.require(tick_engine.now() == 5U, "TickEngine advances global time");
    ctx.require(tick_engine.tickHz() == TouRTOS::Kernel::Config::TickRateHz, "TickEngine uses configured tick rate");
    ctx.require(tick_engine.msToTicks(1000) == tick_engine.tickHz(), "1000 ms maps to the configured tick rate");
}

void testScheduler(TestContext& ctx) {
    TouRTOS::Kernel::Scheduler scheduler;
    TouRTOS::Kernel::TaskControlBlock low{};
    TouRTOS::Kernel::TaskControlBlock high{};
    low.priority = 1U;
    high.priority = 3U;
    scheduler.registerTask(&low);
    scheduler.registerTask(&high);
    scheduler.makeReady(low);
    scheduler.makeReady(high);
    auto* selected = scheduler.selectNext();
    ctx.require(selected == &high, "Scheduler chooses highest-priority ready task");
    scheduler.blockTask(high, 5U);
    scheduler.onTick(5U);
    ctx.require(high.state == TouRTOS::Kernel::TaskState::Ready, "Blocked task wakes on target tick");
}

void testSchedulerPreemptionMode(TestContext& ctx) {
    TouRTOS::Kernel::Scheduler scheduler;
    TouRTOS::Kernel::TaskControlBlock running{};
    TouRTOS::Kernel::TaskControlBlock ready{};
    running.priority = 0U;
    running.state = TouRTOS::Kernel::TaskState::Running;
    ready.priority = TouRTOS::Kernel::Config::MaxPriorities > 1U ? (TouRTOS::Kernel::Config::MaxPriorities - 1U) : 0U;
    ready.state = TouRTOS::Kernel::TaskState::Ready;

    scheduler.registerTask(&running);
    scheduler.registerTask(&ready);

    auto* selected = scheduler.selectNext();
    if (TouRTOS::Kernel::Config::UsePreemption) {
        ctx.require(selected == &ready, "Preemptive mode selects the highest-priority ready task");
    } else {
        ctx.require(selected == &running, "Cooperative mode keeps the currently running task");
    }
}

void testTaskLifecycle(TestContext& ctx) {
    TouRTOS::Kernel::SystemKernel::instance().reset();
    TouRTOS::Application app;
    std::atomic<int> counter{0};

    TouRTOS::Task worker("Worker", [&]() noexcept {
        while (TouRTOS::Task::keepRunning()) {
            ++counter;
            TouRTOS::Task::sleep(2);
        }
    });

    app.start();
    worker.start();
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    app.stop();
    worker.join();

    ctx.require(counter.load() > 0, "Task executes under host runtime");
    ctx.require(worker.controlBlock().state == TouRTOS::Kernel::TaskState::Finished, "Task reaches finished state on shutdown");
}

void testQueueAndSemaphore(TestContext& ctx) {
    TouRTOS::Kernel::SystemKernel::instance().reset();
    TouRTOS::Application app;
    app.start();

    TouRTOS::Queue<int, 2> queue;
    int value = 0;
    ctx.require(queue.send(7, 5), "Queue send succeeds when space is available");
    ctx.require(queue.receive(value, 5) && value == 7, "Queue receive returns enqueued value");
    ctx.require(!queue.receive(value, 5), "Queue receive times out when queue stays empty");

    TouRTOS::BinarySemaphore semaphore(false);
    ctx.require(!semaphore.take(5), "Semaphore take times out when unavailable");
    semaphore.give();
    ctx.require(semaphore.take(5), "Semaphore take succeeds after give");

    app.stop();
}

void testTimerAndEvents(TestContext& ctx) {
    TouRTOS::Kernel::SystemKernel::instance().reset();
    TouRTOS::Application app;
    app.start();

    std::atomic<int> expirations{0};
    TouRTOS::Timer timer("Pulse", 3, TouRTOS::TimerMode::Periodic, [&]() noexcept {
        ++expirations;
    });
    timer.start();
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    app.stop();
    ctx.require(expirations.load() >= 3, "Periodic timer expires multiple times");

    TouRTOS::EventFlags flags;
    flags.set(0x03U);
    ctx.require(flags.waitAll(0x03U, 1) == 0x03U, "EventFlags waitAll returns combined mask");
}

void testDsl(TestContext& ctx) {
    const std::string source =
        "#include \"TaskTOU.h\"\n"
        "#include \"TouRTOS.h\"\n"
        "#include \"InputOutput.h\"\n"
        "#define ledpin 13\n"
        "Setup()\n"
        "{\n"
        "    PINload led(ledpin);\n"
        "    TaskHandle blinkHandle;\n"
        "    led.direction(OUTPUT);\n"
        "    TaskTou ledTask()\n"
        "    begin\n"
        "        while (1) {\n"
        "            led.high();\n"
        "            TouDelayMs(500);\n"
        "            led.low();\n"
        "            TouDelayMs(500);\n"
        "        }\n"
        "    end\n"
        "    ledTask.Priority(2);\n"
        "    ledTask.StackSize(140);\n"
        "    ledTask.Handle(blinkHandle);\n"
        "}\n";

    const auto parsed = TouRTOS::Language::Parser{}.parse(source);
    ctx.require(parsed.ok(), "DSL parser accepts Blink task syntax");
    ctx.require(parsed.program.tasks.size() == 1U, "DSL parser produces one task node");
    ctx.require(parsed.program.has_setup_block, "DSL parser recognizes Setup block");

    const auto generated = TouRTOS::Language::Transpiler{}.transpile(parsed.program, "Blink.tour");
    ctx.require(generated.find("void Setup()") != std::string::npos, "Transpiler emits Setup entry point");
    ctx.require(generated.find("static Task ledTask") != std::string::npos, "Transpiler emits static setup-scoped task");
    ctx.require(generated.find("ledTask.Priority(2);") != std::string::npos, "Transpiler preserves method-style priority");
    ctx.require(generated.find("ledTask.StackSize(140);") != std::string::npos, "Transpiler preserves method-style stack size");
    ctx.require(generated.find("TouDelayMs(500);") != std::string::npos, "Transpiler preserves TouDelayMs()");
    ctx.require(generated.find("ledTask.start();") != std::string::npos, "Transpiler auto-starts setup task");
}

void testTargetProfiles(TestContext& ctx) {
    using namespace std::literals;

    ctx.require(
        TouRTOS::Drivers::TargetConfig::PlatformName == "host"sv,
        "Default target platform is host"
    );
    ctx.require(
        TouRTOS::Drivers::TargetConfig::McuName == "native-host"sv,
        "Default target MCU is native-host"
    );
    ctx.require(TouRTOS::Drivers::TargetConfig::UsesHostRuntime, "Host target enables host runtime");
    ctx.require(TouRTOS::Ports::Host::isSupportedMcu("native-host"), "Host profile exposes native-host MCU");
    ctx.require(TouRTOS::Ports::Avr::isSupportedMcu("atmega328p"), "AVR profile includes ATmega328P");
    ctx.require(TouRTOS::Ports::Pic::isSupportedMcu("pic16f877a"), "PIC profile includes PIC16F877A");
    ctx.require(TouRTOS::Ports::Stm32::isSupportedMcu("stm32f103c8"), "STM32 profile includes STM32F103C8");
    ctx.require(TouRTOS::Ports::Avr::ActiveMcuName == "atmega328p"sv, "AVR default MCU is ATmega328P");
    ctx.require(TouRTOS::Ports::Pic::ActiveMcuName == "pic16f877a"sv, "PIC default MCU is PIC16F877A");
    ctx.require(TouRTOS::Ports::Stm32::ActiveMcuName == "stm32f103c8"sv, "STM32 default MCU is STM32F103C8");
}

void testTouRTOSParameters(TestContext& ctx) {
    ctx.require(TouRTOS::Kernel::Config::TickRateHz > 0U, "TouRTOS parameters expose a positive tick rate");
    ctx.require(TouRTOS::Kernel::Config::DefaultTaskStackSize <= TouRTOS::Kernel::Config::MaxTaskStackSize, "Default stack size stays within the configured max");
    ctx.require(TouRTOS::Kernel::Config::MaxPriorities > 0U, "TouRTOS parameters expose at least one priority level");

    TouRTOS::Task configured(
        "Configured",
        []() noexcept {},
        TouRTOS::TaskConfig{
            .priority = TouRTOS::Kernel::Config::MaxPriorities + 3U,
            .stack_size = TouRTOS::Kernel::Config::MaxTaskStackSize + 256U,
            .quantum_ticks = 0U
        }
    );

    ctx.require(
        configured.controlBlock().priority == TouRTOS::Kernel::Config::MaxPriorities - 1U,
        "Task priority is clamped to the configured priority range"
    );
    ctx.require(
        configured.controlBlock().stack_size == TouRTOS::Kernel::Config::MaxTaskStackSize,
        "Task stack size is clamped to the configured max stack size"
    );
    ctx.require(
        configured.controlBlock().quantum_ticks == TouRTOS::Kernel::Config::DefaultRoundRobinQuantumTicks,
        "Task quantum defaults to the configured round-robin quantum"
    );

    configured.setStackSize(0U);
    configured.setPriority(TouRTOS::Kernel::Config::MaxPriorities + 9U);

    ctx.require(
        configured.controlBlock().stack_size == TouRTOS::Kernel::Config::DefaultTaskStackSize,
        "Setting a zero stack size falls back to the configured default"
    );
    ctx.require(
        configured.controlBlock().priority == TouRTOS::Kernel::Config::MaxPriorities - 1U,
        "Setting an out-of-range priority stays within the configured limits"
    );
}

}  // namespace

int main() {
    TestContext ctx;
    testTickEngine(ctx);
    testScheduler(ctx);
    testSchedulerPreemptionMode(ctx);
    testTaskLifecycle(ctx);
    testQueueAndSemaphore(ctx);
    testTimerAndEvents(ctx);
    testDsl(ctx);
    testTargetProfiles(ctx);
    testTouRTOSParameters(ctx);

    std::cout << "TouRTOS tests: " << ctx.passed << " passed, " << ctx.failed << " failed\n";
    return ctx.failed == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
