#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

#include "TouRTOS/language/Parser.h"
#include "TouRTOS/language/Transpiler.h"

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: tourtosc <input.tour> <output.cpp>\n";
        return 1;
    }

    const std::string input_path = argv[1];
    const std::string output_path = argv[2];

    std::ifstream input(input_path);
    if (!input.is_open()) {
        std::cerr << "Failed to open input file: " << input_path << '\n';
        return 1;
    }

    const std::string source((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    const auto parse_result = TouRTOS::Language::Parser{}.parse(source);
    if (!parse_result.ok()) {
        for (const auto& error : parse_result.errors) {
            std::cerr << error << '\n';
        }
        return 2;
    }

    std::ofstream output(output_path);
    if (!output.is_open()) {
        std::cerr << "Failed to open output file: " << output_path << '\n';
        return 3;
    }

    output << TouRTOS::Language::Transpiler{}.transpile(parse_result.program, input_path);
    return 0;
}
