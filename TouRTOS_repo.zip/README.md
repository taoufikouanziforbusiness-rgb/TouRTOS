# TouRTOS

TouRTOS is a lightweight object-oriented real-time operating system project written in modern embedded-friendly C++. It is designed as a serious educational RTOS that stays small, deterministic, and portable, while exposing a cleaner API than classic C-style RTOS interfaces.

The repository combines four layers:

- `kernel/`: scheduler, task control blocks, tick engine, timer manager, and IPC-facing core logic.
- `framework/`: user-facing C++ classes such as `Task`, `Semaphore`, `Mutex`, `Queue<T, N>`, `Timer`, `EventFlags`, `Led`, `Button`, and `Uart`.
- `drivers/` and `ports/`: generic hardware interfaces plus host, AVR, STM32, and PIC backends.
- `language/`: a first DSL pipeline that parses TouRTOS syntax and transpiles it into C++.

## Why TouRTOS exists

TouRTOS is meant to bridge two worlds:

- low-level RTOS fundamentals such as tasks, ticks, blocking, wake-up timing, and software timers
- a cleaner object model that is easier to teach, extend, and present in an embedded engineering portfolio

The design deliberately avoids exceptions, RTTI, heap-heavy abstractions, and hidden allocations in the core runtime. Static allocation and explicit state are the defaults.

## Current v1 scope

The current codebase provides:

- a host-buildable kernel model with a priority scheduler, round-robin selection among equal priorities, task states, a tick engine, and a timer manager
- host-runtime `Task` execution using host threads as a practical simulator while the portable scheduler and state machine remain explicit in the kernel
- blocking `BinarySemaphore`, `CountingSemaphore`, `Mutex`, `Queue<T, N>`, and `EventFlags`
- software timers with one-shot and periodic modes
- generic driver interfaces through `InputOutput.h`, `Clock.h`, `Serial.h`, `Interrupt.h`, and `TimerHardware.h`
- a usable host port plus scaffold-level AVR, STM32, and PIC targets with concrete MCU profiles such as `atmega328p`, `stm32f103c8`, and `pic16f877a`
- a DSL tool `tourtosc` that parses `task ... begin ... end`, `timer ... begin ... end`, `sleep`, `yield`, and metadata assignments like `.priority` and `.handle`

## Build

```bash
cmake -S . -B build
cmake --build build
```

Build options:

- `-DTOURTOS_BUILD_EXAMPLES=ON|OFF`
- `-DTOURTOS_BUILD_TESTS=ON|OFF`
- `-DTOURTOS_TARGET_PLATFORM=host|avr|stm32|pic`
- `-DTOURTOS_BUILD_AVR_PORT=ON|OFF`
- `-DTOURTOS_BUILD_STM32_PORT=ON|OFF`
- `-DTOURTOS_BUILD_PIC_PORT=ON|OFF`
- `-DTOURTOS_AVR_MCU=atmega328p|atmega2560|attiny85`
- `-DTOURTOS_STM32_MCU=stm32f103c8|stm32f401cc|stm32h743zi`
- `-DTOURTOS_PIC_MCU=pic16f877a|pic18f4550|pic18f46k22`

The default target is `host`. Selecting `avr`, `stm32`, or `pic` switches TouRTOS into scaffold mode for that family and automatically disables the host-only examples and tests.

## TouRTOS Parameters

TouRTOS now exposes a compile-time configuration header at `kernel/include/TouRTOS_parameters.h`.

Edit it to tune core settings such as:

- `TOURTOS_TICK_RATE_HZ`
- `TOURTOS_USE_PREEMPTION`
- `TOURTOS_DEFAULT_TASK_STACK_SIZE`
- `TOURTOS_MAX_TASK_STACK_SIZE`
- `TOURTOS_MAX_TASKS`
- `TOURTOS_MAX_TIMERS`
- `TOURTOS_MAX_PRIORITIES`

Those values feed the kernel through `TouRTOS::Kernel::Config`, so changing the header updates the scheduler model, tick timing, task defaults, and compile-time capacities.

Examples:

```bash
cmake -S . -B build-host -DTOURTOS_TARGET_PLATFORM=host
cmake -S . -B build-avr -DTOURTOS_TARGET_PLATFORM=avr -DTOURTOS_AVR_MCU=atmega328p
cmake -S . -B build-pic -DTOURTOS_TARGET_PLATFORM=pic -DTOURTOS_PIC_MCU=pic18f4550
```

## Run tests

```bash
ctest --test-dir build --output-on-failure
```

## Run examples

Examples are built as host executables:

- `tourtos_example_blink`
- `tourtos_example_producer_consumer`
- `tourtos_example_semaphore_sync`
- `tourtos_example_periodic_timer`
- `tourtos_example_multitask_demo`
- `tourtos_example_dsl_blink`

`Blink.cpp` and `Blink.tour` show the recommended way to consume project-wide values from `TouRTOS_parameters.h` through `TouRTOS::Kernel::Config`.

## DSL

TouRTOS DSL files transpile into C++:

```text
#include "TaskTOU.h"
#include "TouRTOS.h"
#include "TouRTOS/kernel/Config.h"
#include "InputOutput.h"

#define ledpin 13

Setup()
{
    PINload led(ledpin);
    TaskHandle blinkHandle;

    led.direction(OUTPUT);

    TaskTou ledTask()
    begin
        while (1) {
            led.high();
            TouDelayMs(500);
            led.low();
            TouDelayMs(500);
        }
    end

    ledTask.Priority(TouRTOS::Kernel::Config::MaxPriorities > 2U ? 2U : (TouRTOS::Kernel::Config::MaxPriorities - 1U));
    ledTask.StackSize(TouRTOS::Kernel::Config::DefaultTaskStackSize);
    ledTask.Handle(blinkHandle);
}
```

Generate C++ manually with:

```bash
./build/tourtosc examples/Blink.tour build/generated/Blink.cpp
```

The generated output creates real TouRTOS `Task` objects and emits a global `Setup()` function. Public code can use either the standard C++ API or the compatibility-style headers:

```cpp
#include "TaskTOU.h"
#include <TouRTOS.h>
#include "InputOutput.h"
```

## How TouRTOS differs from classic C RTOS APIs

- objects replace opaque C handles for the common framework API
- typed queues use templates instead of `void*` payload management
- the HAL is structured around generic interfaces such as `InputOutput.h`
- the language layer can hide repetitive task boilerplate and transpile to regular C++

## Repository layout

```text
TouRTOS/
  cmake/
  docs/
  drivers/
  examples/
  framework/
  kernel/
  language/
  ports/
    host/
    avr/
    pic/
    stm32/
  tests/
  tools/
```

## Porting TouRTOS to a new MCU

1. Pick the closest existing scaffold first with `TOURTOS_TARGET_PLATFORM` and an MCU profile such as `TOURTOS_AVR_MCU=atmega328p`.
2. Implement `drivers/InputOutput.h` in the new port.
3. Implement `drivers/Clock.h` and the system tick backend.
4. Implement `drivers/Serial.h`, `drivers/Interrupt.h`, and `drivers/TimerHardware.h`.
5. Add startup, critical-section, and context-switch support for the architecture-specific scheduler path.
6. Reuse the framework layer unchanged on top of the new backend.

See [docs/PortingGuide.md](docs/PortingGuide.md) for the detailed checklist.

## Important engineering note

The host port is intentionally honest: it uses host threads to make the API runnable during development and testing, while the kernel itself still exposes explicit task state transitions, tick management, scheduling decisions, and timer handling. That keeps the project practical now without pretending the context-switch port is already complete for bare metal.
