#include <chrono>
#include <thread>

#include <TouRTOS.h>

using namespace TouRTOS;

int main() {
    using namespace std::chrono_literals;

    Application app;
    BinarySemaphore ready(false);
    Led led(13);

    Task waiter("Waiter", [&]() noexcept {
        while (Task::keepRunning()) {
            if (ready.take(100)) {
                led.toggle();
            }
        }
    });

    Task signaler("Signaler", [&]() noexcept {
        while (Task::keepRunning()) {
            Task::sleep(150);
            ready.give();
        }
    });

    app.start();
    waiter.start();
    signaler.start();
    std::this_thread::sleep_for(800ms);
    app.stop();
    waiter.join();
    signaler.join();
    return 0;
}
