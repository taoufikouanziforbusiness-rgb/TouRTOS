#include <atomic>
#include <chrono>
#include <thread>

#include <TouRTOS.h>

using namespace TouRTOS;

int main() {
    using namespace std::chrono_literals;

    Application app;
    Led led(13);
    std::atomic<int> pulses{0};

    Timer heartbeat("Heartbeat", 100, TimerMode::Periodic, [&]() noexcept {
        led.toggle();
        ++pulses;
    });

    app.start();
    heartbeat.start();
    std::this_thread::sleep_for(550ms);
    app.stop();
    return pulses.load() > 0 ? 0 : 1;
}
