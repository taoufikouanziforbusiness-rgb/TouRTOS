#include <chrono>
#include <thread>

#include <TouRTOS.h>
#include "TouRTOS/kernel/Config.h"

using namespace TouRTOS;

int main() {
    using namespace std::chrono_literals;
    constexpr std::size_t BlinkPriority =
        Kernel::Config::MaxPriorities > 2U ? 2U : (Kernel::Config::MaxPriorities - 1U);

    Application app;
    Led led(13);
    Task blink(
        "Blink",
        [&]() noexcept {
            while (Task::keepRunning()) {
                led.toggle();
                Task::sleep(200);
            }
        },
        TaskConfig{
            .priority = BlinkPriority,
            .stack_size = Kernel::Config::DefaultTaskStackSize,
            .quantum_ticks = Kernel::Config::DefaultRoundRobinQuantumTicks
        }
    );

    app.start();
    blink.start();
    std::this_thread::sleep_for(1200ms);
    app.stop();
    blink.join();
    return 0;
}
