#include <atomic>
#include <chrono>
#include <thread>

#include <TouRTOS.h>

using namespace TouRTOS;

int main() {
    using namespace std::chrono_literals;

    Application app;
    Queue<int, 8> queue;
    std::atomic<int> produced{0};
    std::atomic<int> consumed{0};

    Task producer("Producer", [&]() noexcept {
        while (Task::keepRunning()) {
            queue.send(produced.fetch_add(1));
            Task::sleep(50);
        }
    });

    Task consumer("Consumer", [&]() noexcept {
        int value = 0;
        while (Task::keepRunning()) {
            if (queue.receive(value, 20)) {
                consumed.store(value);
            }
            Task::yield();
        }
    });

    producer.setPriority(2);
    consumer.setPriority(1);

    app.start();
    producer.start();
    consumer.start();
    std::this_thread::sleep_for(500ms);
    app.stop();
    producer.join();
    consumer.join();
    return consumed.load() >= 0 ? 0 : 1;
}
