#include <chrono>
#include <thread>

#include <TouRTOS.h>

void Setup();

int main() {
    using namespace std::chrono_literals;

    auto& app = TouApplication();
    app.start();
    Setup();
    std::this_thread::sleep_for(1200ms);
    app.stop();
    return 0;
}
