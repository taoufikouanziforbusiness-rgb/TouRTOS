#include <chrono>
#include <thread>

#include <TouRTOS.h>

using namespace TouRTOS;

int main() {
    using namespace std::chrono_literals;

    Application app;
    Led led(13);
    Button button(2);
    Uart uart(0, 115200);
    Queue<int, 4> events;

    Task poll_button("PollButton", [&]() noexcept {
        while (Task::keepRunning()) {
            events.send(button.read() ? 1 : 0, 10);
            Task::sleep(50);
        }
    });

    Task ui_task("UiTask", [&]() noexcept {
        int state = 0;
        while (Task::keepRunning()) {
            if (events.receive(state, 25)) {
                if (state != 0) {
                    led.toggle();
                    uart.write("button event\n");
                }
            }
            Task::yield();
        }
    });

    app.start();
    poll_button.start();
    ui_task.start();
    std::this_thread::sleep_for(400ms);
    app.stop();
    poll_button.join();
    ui_task.join();
    return 0;
}
