#include "TouRTOS/kernel/TimerManager.h"

#include "TouRTOS/kernel/TickEngine.h"

namespace TouRTOS::Kernel {

SoftwareTimer::SoftwareTimer(const char* name, std::uint32_t period_ms, TimerMode mode, Callback callback) noexcept
    : name_(name), period_ms_(period_ms), mode_(mode), callback_(std::move(callback)) {}

const char* SoftwareTimer::name() const noexcept {
    return name_;
}

std::uint32_t SoftwareTimer::periodMilliseconds() const noexcept {
    return period_ms_;
}

TimerMode SoftwareTimer::mode() const noexcept {
    return mode_;
}

bool SoftwareTimer::active() const noexcept {
    return active_;
}

Tick SoftwareTimer::nextDeadline() const noexcept {
    return next_deadline_;
}

void SoftwareTimer::configure(const char* name, std::uint32_t period_ms, TimerMode mode, Callback callback) noexcept {
    name_ = name;
    period_ms_ = period_ms;
    mode_ = mode;
    callback_ = std::move(callback);
}

void SoftwareTimer::start(Tick now, Tick period_ticks) noexcept {
    active_ = true;
    next_deadline_ = now + period_ticks;
}

void SoftwareTimer::stop() noexcept {
    active_ = false;
    next_deadline_ = 0U;
}

void SoftwareTimer::reload(Tick now, Tick period_ticks) noexcept {
    active_ = true;
    next_deadline_ = now + period_ticks;
}

void SoftwareTimer::fire() noexcept {
    if (callback_) {
        callback_();
    }
}

Status TimerManager::registerTimer(SoftwareTimer* timer) noexcept {
    if (timer == nullptr) {
        return Status::Error;
    }
    if (!timers_.pushBack(timer)) {
        return Status::CapacityExceeded;
    }
    return Status::Ok;
}

void TimerManager::onTick(Tick now, TickEngine& tick_engine) noexcept {
    for (auto* timer : timers_) {
        if (!timer->active()) {
            continue;
        }
        if (timer->nextDeadline() > now) {
            continue;
        }

        timer->fire();
        if (timer->mode() == TimerMode::Periodic) {
            timer->reload(now, tick_engine.msToTicks(timer->periodMilliseconds()));
        } else {
            timer->stop();
        }
    }
}

void TimerManager::reset() noexcept {
    timers_.clear();
}

}  // namespace TouRTOS::Kernel
