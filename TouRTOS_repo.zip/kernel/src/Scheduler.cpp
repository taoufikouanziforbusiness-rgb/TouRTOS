#include "TouRTOS/kernel/Scheduler.h"

namespace TouRTOS::Kernel {

Status Scheduler::registerTask(TaskControlBlock* tcb) noexcept {
    if (tcb == nullptr) {
        return Status::Error;
    }
    if (!tasks_.pushBack(tcb)) {
        return Status::CapacityExceeded;
    }
    return Status::Ok;
}

Status Scheduler::makeReady(TaskControlBlock& tcb) noexcept {
    tcb.state = TaskState::Ready;
    tcb.wake_tick = 0U;
    return Status::Ok;
}

Status Scheduler::makeRunning(TaskControlBlock& tcb) noexcept {
    tcb.state = TaskState::Running;
    return Status::Ok;
}

Status Scheduler::blockTask(TaskControlBlock& tcb, Tick wake_tick) noexcept {
    tcb.state = TaskState::Blocked;
    tcb.wake_tick = wake_tick;
    return Status::Ok;
}

Status Scheduler::suspendTask(TaskControlBlock& tcb) noexcept {
    tcb.state = TaskState::Suspended;
    return Status::Ok;
}

Status Scheduler::resumeTask(TaskControlBlock& tcb) noexcept {
    return makeReady(tcb);
}

void Scheduler::onTick(Tick now) noexcept {
    for (auto* task : tasks_) {
        if (task->state == TaskState::Blocked && task->wake_tick != 0U && task->wake_tick <= now) {
            makeReady(*task);
        }
    }
}

TaskControlBlock* Scheduler::selectNext() noexcept {
    if (!Config::UsePreemption) {
        for (auto* task : tasks_) {
            if (task->state == TaskState::Running) {
                return task;
            }
        }
    }

    TaskControlBlock* selected = nullptr;
    std::size_t selected_priority = 0U;

    for (std::size_t priority = Config::MaxPriorities; priority > 0U; --priority) {
        const std::size_t priority_index = priority - 1U;
        std::size_t ready_count = 0U;
        for (auto* task : tasks_) {
            if ((task->state == TaskState::Ready || task->state == TaskState::Running) && task->priority == priority_index) {
                ++ready_count;
            }
        }
        if (ready_count == 0U) {
            continue;
        }

        const std::size_t start_index = round_robin_cursor_[priority_index] % ready_count;
        std::size_t cursor = 0U;
        for (auto* task : tasks_) {
            if ((task->state == TaskState::Ready || task->state == TaskState::Running) && task->priority == priority_index) {
                if (cursor == start_index) {
                    selected = task;
                    selected_priority = priority_index;
                    break;
                }
                ++cursor;
            }
        }

        if (selected != nullptr) {
            round_robin_cursor_[selected_priority] = (start_index + 1U) % ready_count;
            break;
        }
    }

    if (selected == nullptr && idle_task_ != nullptr) {
        selected = idle_task_;
    }

    return selected;
}

TaskControlBlock* Scheduler::idleTask() noexcept {
    return idle_task_;
}

void Scheduler::setIdleTask(TaskControlBlock* idle_task) noexcept {
    idle_task_ = idle_task;
}

void Scheduler::reset() noexcept {
    tasks_.clear();
    idle_task_ = nullptr;
    for (auto& cursor : round_robin_cursor_) {
        cursor = 0U;
    }
}

}  // namespace TouRTOS::Kernel
