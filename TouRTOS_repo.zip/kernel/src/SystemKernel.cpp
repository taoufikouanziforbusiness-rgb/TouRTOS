#include "TouRTOS/kernel/SystemKernel.h"

#if TOURTOS_USE_HOST_RUNTIME
#include <chrono>
#endif

namespace TouRTOS::Kernel {

SystemKernel& SystemKernel::instance() noexcept {
    static SystemKernel kernel;
    return kernel;
}

TickEngine& SystemKernel::tickEngine() noexcept {
    return tick_engine_;
}

Scheduler& SystemKernel::scheduler() noexcept {
    return scheduler_;
}

TimerManager& SystemKernel::timerManager() noexcept {
    return timer_manager_;
}

Status SystemKernel::registerTask(TaskControlBlock& tcb) noexcept {
    return scheduler_.registerTask(&tcb);
}

Status SystemKernel::registerTimer(SoftwareTimer& timer) noexcept {
    return timer_manager_.registerTimer(&timer);
}

void SystemKernel::startHostTick() noexcept {
    if (running_.exchange(true)) {
        return;
    }
    stop_requested_.store(false);
#if TOURTOS_USE_HOST_RUNTIME
    tick_thread_ = std::thread(&SystemKernel::tickThreadMain, this);
#endif
}

void SystemKernel::stopHostTick() noexcept {
    requestStop();
#if TOURTOS_USE_HOST_RUNTIME
    if (tick_thread_.joinable()) {
        tick_thread_.join();
    }
#endif
    running_.store(false);
}

void SystemKernel::advanceTicks(Tick ticks) noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    std::lock_guard<std::mutex> lock(tick_mutex_);
#endif
    for (Tick index = 0U; index < ticks; ++index) {
        tick_engine_.advance(1U);
        const Tick now = tick_engine_.now();
        scheduler_.onTick(now);
        timer_manager_.onTick(now, tick_engine_);
    }
#if TOURTOS_USE_HOST_RUNTIME
    tick_cv_.notify_all();
#endif
}

void SystemKernel::sleepTask(TaskControlBlock& tcb, std::uint32_t milliseconds) noexcept {
    const Tick wake_tick = tick_engine_.now() + tick_engine_.msToTicks(milliseconds);
    scheduler_.blockTask(tcb, wake_tick);

#if TOURTOS_USE_HOST_RUNTIME
    std::unique_lock<std::mutex> lock(tick_mutex_);
    tick_cv_.wait(lock, [&] {
        return stop_requested_.load() || tick_engine_.now() >= wake_tick;
    });
    lock.unlock();

    scheduler_.makeReady(tcb);
#endif
}

bool SystemKernel::running() const noexcept {
    return running_.load();
}

bool SystemKernel::stopRequested() const noexcept {
    return stop_requested_.load();
}

void SystemKernel::requestStop() noexcept {
    stop_requested_.store(true);
#if TOURTOS_USE_HOST_RUNTIME
    tick_cv_.notify_all();
#endif
}

void SystemKernel::reset() noexcept {
    requestStop();
#if TOURTOS_USE_HOST_RUNTIME
    if (tick_thread_.joinable()) {
        tick_thread_.join();
    }
#endif
    running_.store(false);
    stop_requested_.store(false);
    tick_engine_.reset();
    scheduler_.reset();
    timer_manager_.reset();
}

void SystemKernel::tickThreadMain() noexcept {
#if TOURTOS_USE_HOST_RUNTIME
    const auto tick_hz = static_cast<std::uint64_t>(tick_engine_.tickHz());
    const auto period_ns = tick_hz == 0U ? 1000000ULL : 1000000000ULL / tick_hz;
    const auto sleep_period = std::chrono::nanoseconds(period_ns == 0U ? 1ULL : period_ns);

    while (!stop_requested_.load()) {
        std::this_thread::sleep_for(sleep_period);
        advanceTicks(1U);
    }
#endif
}

}  // namespace TouRTOS::Kernel
