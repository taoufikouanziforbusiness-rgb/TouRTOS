#include "TouRTOS/kernel/TickEngine.h"

namespace TouRTOS::Kernel {

TickEngine::TickEngine(std::uint32_t tick_hz) noexcept : tick_hz_(tick_hz) {}

Tick TickEngine::now() const noexcept {
    return current_tick_.load(std::memory_order_relaxed);
}

std::uint32_t TickEngine::tickHz() const noexcept {
    return tick_hz_;
}

Tick TickEngine::msToTicks(std::uint32_t milliseconds) const noexcept {
    const Tick numerator = static_cast<Tick>(milliseconds) * static_cast<Tick>(tick_hz_);
    const Tick denominator = 1000U;
    const Tick ticks = numerator / denominator;
    return ticks == 0U ? 1U : ticks;
}

void TickEngine::advance(Tick ticks) noexcept {
    current_tick_.fetch_add(ticks, std::memory_order_relaxed);
}

void TickEngine::reset() noexcept {
    current_tick_.store(0U, std::memory_order_relaxed);
}

}  // namespace TouRTOS::Kernel
