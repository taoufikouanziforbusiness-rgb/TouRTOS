#pragma once

#include <cstdint>

namespace TouRTOS::Kernel {

enum class TaskState : std::uint8_t {
    Ready,
    Running,
    Blocked,
    Suspended,
    Finished
};

}  // namespace TouRTOS::Kernel
