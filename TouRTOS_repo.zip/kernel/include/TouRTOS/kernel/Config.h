#pragma once

#include <cstddef>
#include <cstdint>

#include "TouRTOS_parameters.h"

namespace TouRTOS::Kernel::Config {

inline constexpr std::uint32_t TickRateHz = TOURTOS_TICK_RATE_HZ;
inline constexpr bool UsePreemption = TOURTOS_USE_PREEMPTION != 0;
inline constexpr std::size_t DefaultTaskStackSize = TOURTOS_DEFAULT_TASK_STACK_SIZE;
inline constexpr std::size_t MaxTaskStackSize = TOURTOS_MAX_TASK_STACK_SIZE;
inline constexpr std::uint32_t DefaultTickHz = TickRateHz;
inline constexpr std::uint32_t DefaultRoundRobinQuantumTicks = TOURTOS_ROUND_ROBIN_QUANTUM_TICKS;
inline constexpr std::uint32_t WaitForever = 0xFFFFFFFFU;

inline constexpr std::size_t MaxTasks = TOURTOS_MAX_TASKS;
inline constexpr std::size_t MaxTimers = TOURTOS_MAX_TIMERS;
inline constexpr std::size_t MaxWaiters = TOURTOS_MAX_WAITERS;
inline constexpr std::size_t MaxPriorities = TOURTOS_MAX_PRIORITIES;

inline constexpr std::size_t TaskCallableStorage = TOURTOS_TASK_CALLABLE_STORAGE;
inline constexpr std::size_t TimerCallableStorage = TOURTOS_TIMER_CALLABLE_STORAGE;

constexpr std::size_t clampPriority(std::size_t priority) noexcept {
    return priority >= MaxPriorities ? (MaxPriorities - 1U) : priority;
}

constexpr std::size_t clampTaskStackSize(std::size_t stack_size) noexcept {
    if (stack_size == 0U) {
        return DefaultTaskStackSize;
    }
    return stack_size > MaxTaskStackSize ? MaxTaskStackSize : stack_size;
}

constexpr std::size_t clampQuantumTicks(std::size_t quantum_ticks) noexcept {
    return quantum_ticks == 0U ? DefaultRoundRobinQuantumTicks : quantum_ticks;
}

static_assert(TickRateHz > 0U, "TouRTOS tick rate must be greater than zero.");
static_assert(DefaultTaskStackSize > 0U, "TouRTOS default task stack size must be greater than zero.");
static_assert(MaxTaskStackSize > 0U, "TouRTOS max task stack size must be greater than zero.");
static_assert(DefaultTaskStackSize <= MaxTaskStackSize, "TouRTOS default task stack size must not exceed the max task stack size.");
static_assert(MaxTasks > 0U, "TouRTOS must support at least one task.");
static_assert(MaxTimers > 0U, "TouRTOS must support at least one timer.");
static_assert(MaxWaiters > 0U, "TouRTOS must support at least one waiter.");
static_assert(MaxPriorities > 0U, "TouRTOS must support at least one priority level.");
static_assert(TaskCallableStorage > 0U, "TouRTOS task callable storage must be greater than zero.");
static_assert(TimerCallableStorage > 0U, "TouRTOS timer callable storage must be greater than zero.");

}  // namespace TouRTOS::Kernel::Config
