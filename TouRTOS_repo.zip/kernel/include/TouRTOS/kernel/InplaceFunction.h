#pragma once

#include <cstddef>
#include <new>
#include <type_traits>
#include <utility>

namespace TouRTOS::Kernel {

template <std::size_t StorageSize, typename Signature>
class InplaceFunction;

template <std::size_t StorageSize, typename ReturnType, typename... Args>
class InplaceFunction<StorageSize, ReturnType(Args...)> {
public:
    constexpr InplaceFunction() noexcept = default;

    template <typename Callable>
    explicit InplaceFunction(Callable callable) noexcept {
        assign(std::move(callable));
    }

    InplaceFunction(const InplaceFunction& other) noexcept {
        other.copyInto(storage_, invoke_, copy_, destroy_);
    }

    InplaceFunction& operator=(const InplaceFunction& other) noexcept {
        if (this != &other) {
            reset();
            other.copyInto(storage_, invoke_, copy_, destroy_);
        }
        return *this;
    }

    InplaceFunction(InplaceFunction&& other) noexcept {
        other.moveInto(storage_, invoke_, copy_, destroy_);
    }

    InplaceFunction& operator=(InplaceFunction&& other) noexcept {
        if (this != &other) {
            reset();
            other.moveInto(storage_, invoke_, copy_, destroy_);
        }
        return *this;
    }

    ~InplaceFunction() noexcept {
        reset();
    }

    template <typename Callable>
    void assign(Callable callable) noexcept {
        using StoredCallable = std::decay_t<Callable>;
        static_assert(sizeof(StoredCallable) <= StorageSize, "Callable too large for InplaceFunction");
        static_assert(std::is_nothrow_move_constructible_v<StoredCallable>, "Callable must be nothrow move constructible");

        reset();

        new (storage_) StoredCallable(std::move(callable));
        invoke_ = [](void* object, Args... args) -> ReturnType {
            return (*static_cast<StoredCallable*>(object))(std::forward<Args>(args)...);
        };
        copy_ = [](const void* source, void* destination) {
            new (destination) StoredCallable(*static_cast<const StoredCallable*>(source));
        };
        destroy_ = [](void* object) {
            static_cast<StoredCallable*>(object)->~StoredCallable();
        };
    }

    void reset() noexcept {
        if (destroy_ != nullptr) {
            destroy_(storage_);
        }
        invoke_ = nullptr;
        copy_ = nullptr;
        destroy_ = nullptr;
    }

    [[nodiscard]] bool valid() const noexcept {
        return invoke_ != nullptr;
    }

    explicit operator bool() const noexcept {
        return valid();
    }

    ReturnType operator()(Args... args) const {
        return invoke_(const_cast<void*>(static_cast<const void*>(storage_)), std::forward<Args>(args)...);
    }

private:
    using InvokeFn = ReturnType (*)(void*, Args...);
    using CopyFn = void (*)(const void*, void*);
    using DestroyFn = void (*)(void*);

    void copyInto(
        void* destination,
        InvokeFn& destination_invoke,
        CopyFn& destination_copy,
        DestroyFn& destination_destroy
    ) const noexcept {
        if (copy_ != nullptr) {
            copy_(storage_, destination);
        }
        destination_invoke = invoke_;
        destination_copy = copy_;
        destination_destroy = destroy_;
    }

    void moveInto(
        void* destination,
        InvokeFn& destination_invoke,
        CopyFn& destination_copy,
        DestroyFn& destination_destroy
    ) noexcept {
        if (copy_ != nullptr) {
            copy_(storage_, destination);
        }
        destination_invoke = invoke_;
        destination_copy = copy_;
        destination_destroy = destroy_;
        reset();
    }

    alignas(std::max_align_t) unsigned char storage_[StorageSize]{};
    InvokeFn invoke_{nullptr};
    CopyFn copy_{nullptr};
    DestroyFn destroy_{nullptr};
};

}  // namespace TouRTOS::Kernel
