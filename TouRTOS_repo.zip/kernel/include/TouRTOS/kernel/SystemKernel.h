#pragma once

#include <atomic>
#include <cstdint>

#include "TouRTOS/drivers/TargetConfig.h"

#if TOURTOS_USE_HOST_RUNTIME
#include <condition_variable>
#include <mutex>
#include <thread>
#endif

#include "TouRTOS/kernel/Scheduler.h"
#include "TouRTOS/kernel/TickEngine.h"
#include "TouRTOS/kernel/TimerManager.h"

namespace TouRTOS::Kernel {

class SystemKernel {
public:
    static SystemKernel& instance() noexcept;

    TickEngine& tickEngine() noexcept;
    Scheduler& scheduler() noexcept;
    TimerManager& timerManager() noexcept;

    Status registerTask(TaskControlBlock& tcb) noexcept;
    Status registerTimer(SoftwareTimer& timer) noexcept;

    void startHostTick() noexcept;
    void stopHostTick() noexcept;
    void advanceTicks(Tick ticks = 1U) noexcept;
    void sleepTask(TaskControlBlock& tcb, std::uint32_t milliseconds) noexcept;

    [[nodiscard]] bool running() const noexcept;
    [[nodiscard]] bool stopRequested() const noexcept;
    void requestStop() noexcept;
    void reset() noexcept;

private:
    SystemKernel() = default;
    void tickThreadMain() noexcept;

    TickEngine tick_engine_{};
    Scheduler scheduler_{};
    TimerManager timer_manager_{};

    std::atomic<bool> running_{false};
    std::atomic<bool> stop_requested_{false};
#if TOURTOS_USE_HOST_RUNTIME
    std::mutex tick_mutex_{};
    std::condition_variable tick_cv_{};
    std::thread tick_thread_{};
#endif
};

}  // namespace TouRTOS::Kernel
