#pragma once

#include <atomic>
#include <cstdint>

#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/Types.h"

namespace TouRTOS::Kernel {

class TickEngine {
public:
    explicit TickEngine(std::uint32_t tick_hz = Config::DefaultTickHz) noexcept;

    [[nodiscard]] Tick now() const noexcept;
    [[nodiscard]] std::uint32_t tickHz() const noexcept;
    [[nodiscard]] Tick msToTicks(std::uint32_t milliseconds) const noexcept;
    void advance(Tick ticks = 1U) noexcept;
    void reset() noexcept;

private:
    std::atomic<Tick> current_tick_{0U};
    std::uint32_t tick_hz_{Config::DefaultTickHz};
};

}  // namespace TouRTOS::Kernel
