#pragma once

#include <array>
#include <cstddef>
#include <utility>

namespace TouRTOS::Kernel {

template <typename T, std::size_t Capacity>
class StaticVector {
public:
    constexpr bool pushBack(const T& value) noexcept {
        if (size_ >= Capacity) {
            return false;
        }
        data_[size_++] = value;
        return true;
    }

    constexpr bool pushBack(T&& value) noexcept {
        if (size_ >= Capacity) {
            return false;
        }
        data_[size_++] = std::move(value);
        return true;
    }

    constexpr void clear() noexcept {
        size_ = 0U;
    }

    [[nodiscard]] constexpr std::size_t size() const noexcept {
        return size_;
    }

    [[nodiscard]] constexpr bool empty() const noexcept {
        return size_ == 0U;
    }

    [[nodiscard]] constexpr T* begin() noexcept {
        return data_.data();
    }

    [[nodiscard]] constexpr const T* begin() const noexcept {
        return data_.data();
    }

    [[nodiscard]] constexpr T* end() noexcept {
        return data_.data() + size_;
    }

    [[nodiscard]] constexpr const T* end() const noexcept {
        return data_.data() + size_;
    }

    [[nodiscard]] constexpr T& operator[](std::size_t index) noexcept {
        return data_[index];
    }

    [[nodiscard]] constexpr const T& operator[](std::size_t index) const noexcept {
        return data_[index];
    }

    constexpr bool eraseAt(std::size_t index) noexcept {
        if (index >= size_) {
            return false;
        }
        for (std::size_t cursor = index; cursor + 1U < size_; ++cursor) {
            data_[cursor] = std::move(data_[cursor + 1U]);
        }
        --size_;
        return true;
    }

private:
    std::array<T, Capacity> data_{};
    std::size_t size_{0U};
};

}  // namespace TouRTOS::Kernel
