#pragma once

#include <cstdint>

#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/InplaceFunction.h"
#include "TouRTOS/kernel/Types.h"

namespace TouRTOS::Kernel {

enum class TimerMode : std::uint8_t {
    OneShot,
    Periodic
};

class SoftwareTimer {
public:
    using Callback = InplaceFunction<Config::TimerCallableStorage, void()>;

    SoftwareTimer() = default;
    SoftwareTimer(const char* name, std::uint32_t period_ms, TimerMode mode, Callback callback) noexcept;

    [[nodiscard]] const char* name() const noexcept;
    [[nodiscard]] std::uint32_t periodMilliseconds() const noexcept;
    [[nodiscard]] TimerMode mode() const noexcept;
    [[nodiscard]] bool active() const noexcept;
    [[nodiscard]] Tick nextDeadline() const noexcept;

    void configure(const char* name, std::uint32_t period_ms, TimerMode mode, Callback callback) noexcept;
    void start(Tick now, Tick period_ticks) noexcept;
    void stop() noexcept;
    void reload(Tick now, Tick period_ticks) noexcept;
    void fire() noexcept;

private:
    const char* name_{"timer"};
    std::uint32_t period_ms_{0U};
    TimerMode mode_{TimerMode::OneShot};
    Callback callback_{};
    bool active_{false};
    Tick next_deadline_{0U};
};

}  // namespace TouRTOS::Kernel
