#pragma once

#include <array>
#include <cstddef>

#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/StaticVector.h"
#include "TouRTOS/kernel/TaskControlBlock.h"
#include "TouRTOS/kernel/Types.h"

namespace TouRTOS::Kernel {

class Scheduler {
public:
    Status registerTask(TaskControlBlock* tcb) noexcept;
    Status makeReady(TaskControlBlock& tcb) noexcept;
    Status makeRunning(TaskControlBlock& tcb) noexcept;
    Status blockTask(TaskControlBlock& tcb, Tick wake_tick) noexcept;
    Status suspendTask(TaskControlBlock& tcb) noexcept;
    Status resumeTask(TaskControlBlock& tcb) noexcept;
    void onTick(Tick now) noexcept;
    [[nodiscard]] TaskControlBlock* selectNext() noexcept;
    [[nodiscard]] TaskControlBlock* idleTask() noexcept;
    void setIdleTask(TaskControlBlock* idle_task) noexcept;
    void reset() noexcept;

private:
    StaticVector<TaskControlBlock*, Config::MaxTasks> tasks_{};
    std::array<std::size_t, Config::MaxPriorities> round_robin_cursor_{};
    TaskControlBlock* idle_task_{nullptr};
};

}  // namespace TouRTOS::Kernel
