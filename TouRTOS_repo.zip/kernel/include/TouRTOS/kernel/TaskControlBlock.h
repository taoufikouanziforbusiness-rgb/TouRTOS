#pragma once

#include <cstddef>

#include "TouRTOS/kernel/TaskState.h"
#include "TouRTOS/kernel/Types.h"

namespace TouRTOS {
class Task;
class TaskHandle;
}

namespace TouRTOS::Kernel {

struct TaskControlBlock {
    TaskId id{0U};
    const char* name{"unnamed"};
    std::size_t stack_size{0U};
    std::size_t priority{0U};
    std::size_t quantum_ticks{0U};
    Tick wake_tick{0U};
    TaskState state{TaskState::Suspended};
    TouRTOS::Task* owner{nullptr};
    TouRTOS::TaskHandle* handle{nullptr};
};

}  // namespace TouRTOS::Kernel
