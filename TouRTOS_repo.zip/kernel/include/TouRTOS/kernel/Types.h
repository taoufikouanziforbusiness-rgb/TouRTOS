#pragma once

#include <cstdint>

namespace TouRTOS::Kernel {

using Tick = std::uint64_t;
using TaskId = std::uint32_t;

enum class Status : std::uint8_t {
    Ok,
    Timeout,
    Full,
    Empty,
    Busy,
    InvalidState,
    CapacityExceeded,
    NotFound,
    Error
};

}  // namespace TouRTOS::Kernel
