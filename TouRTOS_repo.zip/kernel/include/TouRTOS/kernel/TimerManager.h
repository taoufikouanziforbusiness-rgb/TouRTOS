#pragma once

#include "TouRTOS/kernel/Config.h"
#include "TouRTOS/kernel/SoftwareTimer.h"
#include "TouRTOS/kernel/StaticVector.h"
#include "TouRTOS/kernel/TickEngine.h"
#include "TouRTOS/kernel/Types.h"

namespace TouRTOS::Kernel {

class TimerManager {
public:
    Status registerTimer(SoftwareTimer* timer) noexcept;
    void onTick(Tick now, TickEngine& tick_engine) noexcept;
    void reset() noexcept;

private:
    StaticVector<SoftwareTimer*, Config::MaxTimers> timers_{};
};

}  // namespace TouRTOS::Kernel
