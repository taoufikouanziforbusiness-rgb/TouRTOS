#pragma once

#include <cstdint>

#include "TouRTOS/drivers/InputOutput.h"

inline constexpr auto INPUT = TouRTOS::Drivers::PinMode::Input;
inline constexpr auto OUTPUT = TouRTOS::Drivers::PinMode::Output;
inline constexpr auto INPUT_PULLUP = TouRTOS::Drivers::PinMode::InputPullup;

class PINload {
public:
    explicit PINload(std::uint32_t pin) noexcept : pin_(pin) {}

    void direction(TouRTOS::Drivers::PinMode mode) const noexcept {
        TouRTOS::Drivers::configurePin(pin_, mode);
    }

    void high() const noexcept {
        TouRTOS::Drivers::writePin(pin_, TouRTOS::Drivers::PinState::High);
    }

    void low() const noexcept {
        TouRTOS::Drivers::writePin(pin_, TouRTOS::Drivers::PinState::Low);
    }

    void toggle() const noexcept {
        TouRTOS::Drivers::togglePin(pin_);
    }

    [[nodiscard]] bool read() const noexcept {
        return TouRTOS::Drivers::readPin(pin_) == TouRTOS::Drivers::PinState::High;
    }

private:
    std::uint32_t pin_{0U};
};
