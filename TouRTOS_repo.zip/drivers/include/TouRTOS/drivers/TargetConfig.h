#pragma once

#ifndef TOURTOS_TARGET_PLATFORM_NAME
#define TOURTOS_TARGET_PLATFORM_NAME "host"
#endif

#ifndef TOURTOS_TARGET_MCU_NAME
#define TOURTOS_TARGET_MCU_NAME "native-host"
#endif

#ifndef TOURTOS_USE_HOST_RUNTIME
#define TOURTOS_USE_HOST_RUNTIME 1
#endif

namespace TouRTOS::Drivers::TargetConfig {

inline constexpr const char* PlatformName = TOURTOS_TARGET_PLATFORM_NAME;
inline constexpr const char* McuName = TOURTOS_TARGET_MCU_NAME;
inline constexpr bool UsesHostRuntime = TOURTOS_USE_HOST_RUNTIME != 0;

}  // namespace TouRTOS::Drivers::TargetConfig
