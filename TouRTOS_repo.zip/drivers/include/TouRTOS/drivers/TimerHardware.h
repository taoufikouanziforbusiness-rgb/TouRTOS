#pragma once

#include <cstdint>

namespace TouRTOS::Drivers {

bool configureSystemTickTimer(std::uint32_t tick_hz, void (*handler)()) noexcept;
void startSystemTickTimer() noexcept;
void stopSystemTickTimer() noexcept;

}  // namespace TouRTOS::Drivers
