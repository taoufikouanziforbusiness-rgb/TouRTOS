#pragma once

#include <cstdint>

namespace TouRTOS::Drivers {

bool initializeClock(std::uint32_t system_clock_hz) noexcept;
std::uint32_t systemClockHz() noexcept;
std::uint64_t platformMilliseconds() noexcept;

}  // namespace TouRTOS::Drivers
