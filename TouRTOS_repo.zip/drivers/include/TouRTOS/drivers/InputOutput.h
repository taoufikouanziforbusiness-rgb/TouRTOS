#pragma once

#include <cstdint>

namespace TouRTOS::Drivers {

enum class PinMode : std::uint8_t {
    Input,
    Output,
    InputPullup
};

enum class PinState : std::uint8_t {
    Low = 0U,
    High = 1U
};

bool initializeInputOutput() noexcept;
bool configurePin(std::uint32_t pin, PinMode mode) noexcept;
bool writePin(std::uint32_t pin, PinState state) noexcept;
PinState readPin(std::uint32_t pin) noexcept;
bool togglePin(std::uint32_t pin) noexcept;

}  // namespace TouRTOS::Drivers
