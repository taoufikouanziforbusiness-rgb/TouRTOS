#pragma once

#include <cstdint>

namespace TouRTOS::Drivers {

using InterruptHandler = void (*)();

bool attachInterrupt(std::uint32_t irq, InterruptHandler handler) noexcept;
void enableInterrupt(std::uint32_t irq) noexcept;
void disableInterrupt(std::uint32_t irq) noexcept;

}  // namespace TouRTOS::Drivers
