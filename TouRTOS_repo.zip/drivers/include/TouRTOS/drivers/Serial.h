#pragma once

#include <cstddef>
#include <cstdint>

namespace TouRTOS::Drivers {

bool openSerial(std::uint8_t instance, std::uint32_t baud_rate) noexcept;
bool writeSerial(std::uint8_t instance, const char* data, std::size_t size) noexcept;
std::size_t readSerial(std::uint8_t instance, char* buffer, std::size_t size) noexcept;

}  // namespace TouRTOS::Drivers
