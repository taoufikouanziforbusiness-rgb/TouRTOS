# Scheduler Design

TouRTOS v1 uses a priority scheduler with round-robin selection among tasks that share the same priority level.

## Policy

- highest numeric priority wins
- equal-priority tasks rotate through a round-robin cursor
- blocked tasks are excluded until their wake tick expires
- suspended tasks are excluded until resumed
- an idle task hook exists in the scheduler model even though the host port does not yet use a dedicated idle-thread object

## Why this design

- it matches common embedded RTOS expectations
- it is easy to reason about in tests
- it is portable across microcontrollers
- it leaves space for later preemption and time-slice enforcement in architecture-specific ports

## Host limitation

The host runtime does not yet drive actual execution from `Scheduler::selectNext()`. Instead, the scheduler remains the canonical state machine and arbitration model, while host threads make the framework executable on a desktop build.
