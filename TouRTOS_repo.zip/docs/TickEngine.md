# Tick Engine Design

The tick engine is the time base of TouRTOS.

## Responsibilities

- store the global monotonic tick count
- convert milliseconds to kernel ticks
- provide the common notion of time for task sleeps, IPC timeouts, and software timers

## Default configuration

- tick frequency: `1000 Hz`
- tick period: `1 ms`

## Why 1 ms

- good educational visibility
- simple timeout reasoning
- acceptable default for many small microcontroller systems
- still easy to change later if a port needs a different rate

## Interaction with the kernel

On every tick:

1. `TickEngine` increments the global time.
2. `Scheduler` wakes tasks whose `wake_tick` has been reached.
3. `TimerManager` checks periodic and one-shot software timers.

The same tick source therefore drives all time-based services.
