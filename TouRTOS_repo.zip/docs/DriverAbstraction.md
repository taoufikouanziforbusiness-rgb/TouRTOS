# Driver Abstraction Philosophy

TouRTOS uses generic driver headers so the framework stays MCU-agnostic.

## Mandatory interfaces

- `InputOutput.h`
- `Clock.h`
- `Serial.h`
- `Interrupt.h`
- `TimerHardware.h`

`InputOutput.h` is the central digital I/O abstraction and is mandatory for every port.

## Pattern

- `drivers/InputOutput.h`
- `ports/host/src/InputOutput.cpp`
- `ports/avr/src/InputOutput.cpp`
- `ports/pic/src/InputOutput.cpp`
- `ports/stm32/src/InputOutput.cpp`

The same pattern is used for the clock and serial backends.

## Why this matters

- the public framework API remains stable
- new microcontrollers only implement the generic contracts
- examples and DSL-generated applications do not need to know the target-specific register layer
