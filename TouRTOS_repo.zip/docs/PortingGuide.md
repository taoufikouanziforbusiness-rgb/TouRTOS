# Porting Guide

This guide describes how to add a new TouRTOS microcontroller port.

TouRTOS currently ships scaffold profiles for:

- AVR: `atmega328p`, `atmega2560`, `attiny85`
- STM32: `stm32f103c8`, `stm32f401cc`, `stm32h743zi`
- PIC: `pic16f877a`, `pic18f4550`, `pic18f46k22`

Select one of those with `-DTOURTOS_TARGET_PLATFORM=<family>` and the matching `-DTOURTOS_<FAMILY>_MCU=<device>` option before adding a new family from scratch.

## 1. Create the port directory

Add:

- `ports/<mcu>/include/TouRTOS/ports/<mcu>/Platform.h`
- `ports/<mcu>/src/InputOutput.cpp`
- `ports/<mcu>/src/Clock.cpp`
- `ports/<mcu>/src/Serial.cpp`
- `ports/<mcu>/src/Interrupt.cpp`
- `ports/<mcu>/src/TimerHardware.cpp`

The current non-host ports are scaffold builds: they compile without the host-thread runtime, but they still need real register-level HAL logic and scheduler context-switch support before they become runnable bare-metal targets.

## 2. Implement the mandatory HAL contracts

### `InputOutput.h`

- configure pins
- write digital outputs
- read digital inputs
- toggle outputs

### `Clock.h`

- initialize system frequency
- report current system clock frequency
- expose a platform millisecond counter if available

### `Serial.h`

- open a UART instance
- write data
- optionally read data

### `Interrupt.h`

- attach handlers
- enable/disable interrupts

### `TimerHardware.h`

- configure the system tick timer
- start/stop the hardware tick source

## 3. Add kernel-port integration

The current repository already separates the scheduler core from execution. A real bare-metal port must add:

- startup code
- critical section control
- ISR entry/exit hooks
- context-save/context-restore logic
- stack initialization for first task start
- an idle task strategy

## 4. Verify on host first

TouRTOS is structured so the kernel and framework logic can be exercised on the host build before moving to the MCU.
