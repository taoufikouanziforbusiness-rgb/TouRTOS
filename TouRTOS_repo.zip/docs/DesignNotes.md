# Design Notes And Backlog

## Chosen tradeoffs for v1

- host-mode execution uses host threads so the framework is runnable immediately
- the portable scheduler and timer model are implemented separately and documented clearly
- queue and synchronization objects use fixed-capacity storage or bounded state
- the DSL deliberately supports a focused subset first instead of pretending to be a full language

## Next milestones

- architecture-specific context-switch code for AVR and Cortex-M
- explicit idle task object and idle statistics
- delay-until API
- ISR-safe queue and semaphore entry points
- timer command queue for safer callback management
- queue/semaphore declarations in the DSL
- better generated-code packaging with headers and namespaces per module
- optional tracing and scheduling diagnostics
