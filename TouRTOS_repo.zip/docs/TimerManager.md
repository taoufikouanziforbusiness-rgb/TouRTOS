# Timer Manager Design

Software timers are first-class TouRTOS objects backed by `kernel/SoftwareTimer` and `kernel/TimerManager`.

## Supported modes

- `OneShot`
- `Periodic`

## Flow

1. A `framework/Timer` registers a `kernel/SoftwareTimer`.
2. `Timer::start()` converts milliseconds to ticks and arms the deadline.
3. `TimerManager::onTick()` fires callbacks whose deadlines have expired.
4. Periodic timers reload automatically. One-shot timers stop after the first expiration.

## Why software timers matter

- they avoid dedicating a task to every periodic action
- they reuse the same deterministic tick source as the rest of the kernel
- they are a natural place for future features such as timer command queues, deferred callbacks, and tracing
