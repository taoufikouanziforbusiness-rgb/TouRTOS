# Examples Guide

## `Blink.cpp`

Minimal task and `Led` usage, now wired to `TouRTOS_parameters.h` through `TouRTOS::Kernel::Config`.

## `ProducerConsumer.cpp`

Two tasks communicating through `Queue<int, 8>`.

## `SemaphoreSync.cpp`

Binary semaphore synchronization between a waiter and a signaler task.

## `PeriodicTimer.cpp`

Software timer callback toggling a simulated LED.

## `MultiTaskDemo.cpp`

Uses `Led`, `Button`, `Uart`, and a queue to form a tiny multi-task application.

## `Blink.tour`

Demonstrates the DSL syntax and shows that DSL code can also consume `TouRTOS::Kernel::Config` values from `TouRTOS_parameters.h`.
