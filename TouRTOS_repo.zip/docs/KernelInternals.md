# Kernel Internals

## Core modules

- `TickEngine`
  Owns the monotonic system tick counter and time conversion logic.
- `Scheduler`
  Tracks `TaskControlBlock` objects, task states, wake ticks, and next-task selection.
- `TimerManager`
  Tracks software timers and dispatches callbacks on expiration.
- `TaskControlBlock`
  Stores task metadata: id, name, priority, state, stack size, wake tick, and handle linkage.
- `SystemKernel`
  Coordinates tick advancement, scheduler wake-ups, timer expiration, and host-mode tick execution.

## Task states

- `Ready`
- `Running`
- `Blocked`
- `Suspended`
- `Finished`

The kernel currently keeps these state transitions explicit even though the host port uses threads for execution.

## Determinism choices

- tick-to-time conversion is centralized in `TickEngine`
- blocked tasks wake from explicit `wake_tick` checks
- timers are driven by the same tick source as sleeps and timeouts
- queue/semaphore/mutex/event waits all use tick-derived deadlines
