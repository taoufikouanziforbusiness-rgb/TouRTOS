# TouRTOS Architecture

TouRTOS is split into explicit layers so the project can grow from a host-simulated educational RTOS into a portable embedded ecosystem.

## Layer map

1. `language/`
   The DSL toolchain tokenizes, parses, and transpiles TouRTOS syntax into C++.
2. `framework/`
   This is the public object-oriented API: tasks, semaphores, queues, timers, event flags, and device wrappers.
3. `kernel/`
   The kernel contains the scheduler model, task states, tick engine, timer manager, and the deterministic core that real ports will eventually drive.
4. `drivers/`
   Generic hardware interfaces define what every microcontroller backend must implement.
5. `ports/`
   Host, AVR, and STM32 backends plug concrete hardware behavior into the generic driver contracts.

## Design stance

- deterministic timing behavior is the priority over feature count
- static sizing is preferred over unbounded dynamic allocation
- the kernel is intentionally small and readable
- the host port is used as a development simulator, not as a claim that bare-metal context switching is already solved

## Current execution model

- `kernel/` models scheduling decisions, wake ticks, timer expiration, and task state transitions
- `framework/Task` executes on the host port with a dedicated host thread per task
- `kernel/SystemKernel` owns the global tick thread in host mode and updates the scheduler and timer manager every millisecond
- real embedded ports will replace the host-thread execution model with architecture-specific context switching and stack management
