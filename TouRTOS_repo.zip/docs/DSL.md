# TouRTOS DSL

TouRTOS includes a first transpiler stage that turns a compact user syntax into ordinary TouRTOS C++.

## Supported syntax in v1

- `task NAME(args) begin ... end`
- `TaskTou NAME(args) begin ... end`
- `Setup() { ... }`
- `timer NAME(period, mode) begin ... end`
- `sleep(ms)`
- `yield()`
- `TouDelayMs(ms)`
- method-style task configuration:
  `TaskName.Priority(value);`
  `TaskName.StackSize(value);`
  `TaskName.Handle(handleName);`
- `TaskName.priority = value;`
- `TaskName.handle = handleName;`
- inline task metadata:
  `priority 2;`
  `handle blinkHandle;`

## Example

```text
#include "TaskTOU.h"
#include "TouRTOS.h"
#include "TouRTOS/kernel/Config.h"
#include "InputOutput.h"

#define ledpin 13

Setup()
{
    PINload led(ledpin);
    TaskHandle blinkHandle;

    led.direction(OUTPUT);

    TaskTou ledTask()
    begin
        while (1) {
            led.high();
            TouDelayMs(500);
            led.low();
            TouDelayMs(500);
        }
    end

    ledTask.Priority(TouRTOS::Kernel::Config::MaxPriorities > 2U ? 2U : (TouRTOS::Kernel::Config::MaxPriorities - 1U));
    ledTask.StackSize(TouRTOS::Kernel::Config::DefaultTaskStackSize);
    ledTask.Handle(blinkHandle);
}
```

## Generated form

The transpiler emits C++ roughly equivalent to:

```cpp
void Setup() {
    PINload led(ledpin);
    static Task ledTask("ledTask", [=]() {
        while (1) {
            led.high();
            TouDelayMs(500);
            led.low();
            TouDelayMs(500);
        }
    });

    ledTask.Priority(TouRTOS::Kernel::Config::MaxPriorities > 2U ? 2U : (TouRTOS::Kernel::Config::MaxPriorities - 1U));
    ledTask.StackSize(TouRTOS::Kernel::Config::DefaultTaskStackSize);
    ledTask.Handle(blinkHandle);
    ledTask.start();
}
```

It emits a global `Setup()` function and auto-starts the tasks declared inside it.

Because task bodies are preserved as TouRTOS-flavored C++, DSL code can read `TouRTOS::Kernel::Config` and follow the same `TouRTOS_parameters.h` file as regular C++ applications.

## Current limits

- task bodies are preserved as raw C++-like text
- the parser is line-oriented around `begin` and `end`
- future language growth should add better expression parsing, declarations for queues and semaphores, and multiple translation units
