#include "TouRTOS/drivers/Interrupt.h"

namespace TouRTOS::Drivers {

bool attachInterrupt(std::uint32_t, InterruptHandler) noexcept {
    return false;
}

void enableInterrupt(std::uint32_t) noexcept {}

void disableInterrupt(std::uint32_t) noexcept {}

}  // namespace TouRTOS::Drivers
