#include "TouRTOS/drivers/Serial.h"

namespace TouRTOS::Drivers {

bool openSerial(std::uint8_t, std::uint32_t) noexcept {
    return false;
}

bool writeSerial(std::uint8_t, const char*, std::size_t) noexcept {
    return false;
}

std::size_t readSerial(std::uint8_t, char*, std::size_t) noexcept {
    return 0U;
}

}  // namespace TouRTOS::Drivers
