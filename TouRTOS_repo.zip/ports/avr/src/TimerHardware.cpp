#include "TouRTOS/drivers/TimerHardware.h"

namespace TouRTOS::Drivers {

bool configureSystemTickTimer(std::uint32_t, void (*)()) noexcept {
    return false;
}

void startSystemTickTimer() noexcept {}

void stopSystemTickTimer() noexcept {}

}  // namespace TouRTOS::Drivers
