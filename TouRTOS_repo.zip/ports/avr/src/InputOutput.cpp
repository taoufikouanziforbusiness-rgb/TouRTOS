#include "TouRTOS/drivers/InputOutput.h"

namespace TouRTOS::Drivers {

bool initializeInputOutput() noexcept {
    return false;
}

bool configurePin(std::uint32_t, PinMode) noexcept {
    return false;
}

bool writePin(std::uint32_t, PinState) noexcept {
    return false;
}

PinState readPin(std::uint32_t) noexcept {
    return PinState::Low;
}

bool togglePin(std::uint32_t) noexcept {
    return false;
}

}  // namespace TouRTOS::Drivers
