#include "TouRTOS/drivers/Clock.h"

namespace TouRTOS::Drivers {

bool initializeClock(std::uint32_t) noexcept {
    return false;
}

std::uint32_t systemClockHz() noexcept {
    return 0U;
}

std::uint64_t platformMilliseconds() noexcept {
    return 0U;
}

}  // namespace TouRTOS::Drivers
