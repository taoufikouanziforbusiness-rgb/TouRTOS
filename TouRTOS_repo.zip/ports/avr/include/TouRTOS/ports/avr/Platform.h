#pragma once

#include <array>
#include <string_view>

namespace TouRTOS::Ports::Avr {

constexpr const char* Name = "avr";
inline constexpr std::array<std::string_view, 3U> SupportedMcuNames{
    "atmega328p",
    "atmega2560",
    "attiny85"
};

constexpr bool isSupportedMcu(std::string_view name) noexcept {
    for (const auto supported_name : SupportedMcuNames) {
        if (supported_name == name) {
            return true;
        }
    }
    return false;
}

#if defined(TOURTOS_AVR_MCU_ATMEGA2560)
constexpr const char* ActiveMcuName = "atmega2560";
#elif defined(TOURTOS_AVR_MCU_ATTINY85)
constexpr const char* ActiveMcuName = "attiny85";
#else
constexpr const char* ActiveMcuName = "atmega328p";
#endif

}  // namespace TouRTOS::Ports::Avr
