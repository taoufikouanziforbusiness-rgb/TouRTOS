#pragma once

#include <array>
#include <string_view>

namespace TouRTOS::Ports::Pic {

constexpr const char* Name = "pic";
inline constexpr std::array<std::string_view, 3U> SupportedMcuNames{
    "pic16f877a",
    "pic18f4550",
    "pic18f46k22"
};

constexpr bool isSupportedMcu(std::string_view name) noexcept {
    for (const auto supported_name : SupportedMcuNames) {
        if (supported_name == name) {
            return true;
        }
    }
    return false;
}

#if defined(TOURTOS_PIC_MCU_PIC18F4550)
constexpr const char* ActiveMcuName = "pic18f4550";
#elif defined(TOURTOS_PIC_MCU_PIC18F46K22)
constexpr const char* ActiveMcuName = "pic18f46k22";
#else
constexpr const char* ActiveMcuName = "pic16f877a";
#endif

}  // namespace TouRTOS::Ports::Pic
