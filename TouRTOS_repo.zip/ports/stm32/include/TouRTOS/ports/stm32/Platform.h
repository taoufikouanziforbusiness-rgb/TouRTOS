#pragma once

#include <array>
#include <string_view>

namespace TouRTOS::Ports::Stm32 {

constexpr const char* Name = "stm32";
inline constexpr std::array<std::string_view, 3U> SupportedMcuNames{
    "stm32f103c8",
    "stm32f401cc",
    "stm32h743zi"
};

constexpr bool isSupportedMcu(std::string_view name) noexcept {
    for (const auto supported_name : SupportedMcuNames) {
        if (supported_name == name) {
            return true;
        }
    }
    return false;
}

#if defined(TOURTOS_STM32_MCU_STM32F401CC)
constexpr const char* ActiveMcuName = "stm32f401cc";
#elif defined(TOURTOS_STM32_MCU_STM32H743ZI)
constexpr const char* ActiveMcuName = "stm32h743zi";
#else
constexpr const char* ActiveMcuName = "stm32f103c8";
#endif

}  // namespace TouRTOS::Ports::Stm32
