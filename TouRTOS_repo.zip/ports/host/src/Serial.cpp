#include "TouRTOS/drivers/Serial.h"

#include <cstring>
#include <iostream>
#include <mutex>

namespace TouRTOS::Drivers {

namespace {
std::mutex g_serial_mutex{};
}  // namespace

bool openSerial(std::uint8_t, std::uint32_t) noexcept {
    return true;
}

bool writeSerial(std::uint8_t instance, const char* data, std::size_t size) noexcept {
    std::lock_guard<std::mutex> lock(g_serial_mutex);
    std::cout << "[UART" << static_cast<int>(instance) << "] ";
    std::cout.write(data, static_cast<std::streamsize>(size));
    std::cout.flush();
    return true;
}

std::size_t readSerial(std::uint8_t, char* buffer, std::size_t size) noexcept {
    if (buffer == nullptr || size == 0U) {
        return 0U;
    }
    const char* sample = "host-input";
    const auto sample_size = std::strlen(sample);
    const auto copy_size = sample_size < size ? sample_size : size;
    std::memcpy(buffer, sample, copy_size);
    return copy_size;
}

}  // namespace TouRTOS::Drivers
