#include "TouRTOS/drivers/TimerHardware.h"

namespace TouRTOS::Drivers {

namespace {
void (*g_tick_handler)() = nullptr;
std::uint32_t g_tick_hz = 0U;
}  // namespace

bool configureSystemTickTimer(std::uint32_t tick_hz, void (*handler)()) noexcept {
    g_tick_hz = tick_hz;
    g_tick_handler = handler;
    return g_tick_hz != 0U && g_tick_handler != nullptr;
}

void startSystemTickTimer() noexcept {}

void stopSystemTickTimer() noexcept {}

}  // namespace TouRTOS::Drivers
