#include "TouRTOS/drivers/Clock.h"

#include <chrono>

namespace TouRTOS::Drivers {

namespace {
std::uint32_t g_system_clock_hz = 0U;
std::chrono::steady_clock::time_point g_start_time = std::chrono::steady_clock::now();
}  // namespace

bool initializeClock(std::uint32_t system_clock_hz) noexcept {
    g_system_clock_hz = system_clock_hz;
    g_start_time = std::chrono::steady_clock::now();
    return true;
}

std::uint32_t systemClockHz() noexcept {
    return g_system_clock_hz;
}

std::uint64_t platformMilliseconds() noexcept {
    const auto elapsed = std::chrono::steady_clock::now() - g_start_time;
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count());
}

}  // namespace TouRTOS::Drivers
