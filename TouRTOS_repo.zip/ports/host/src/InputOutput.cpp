#include "TouRTOS/drivers/InputOutput.h"

#include <array>
#include <mutex>

namespace TouRTOS::Drivers {

namespace {
constexpr std::size_t MaxPins = 128U;
std::array<PinMode, MaxPins> g_modes{};
std::array<PinState, MaxPins> g_states{};
std::mutex g_io_mutex{};
}  // namespace

bool initializeInputOutput() noexcept {
    std::lock_guard<std::mutex> lock(g_io_mutex);
    g_modes.fill(PinMode::Input);
    g_states.fill(PinState::Low);
    return true;
}

bool configurePin(std::uint32_t pin, PinMode mode) noexcept {
    if (pin >= MaxPins) {
        return false;
    }
    std::lock_guard<std::mutex> lock(g_io_mutex);
    g_modes[pin] = mode;
    return true;
}

bool writePin(std::uint32_t pin, PinState state) noexcept {
    if (pin >= MaxPins) {
        return false;
    }
    std::lock_guard<std::mutex> lock(g_io_mutex);
    g_states[pin] = state;
    return true;
}

PinState readPin(std::uint32_t pin) noexcept {
    if (pin >= MaxPins) {
        return PinState::Low;
    }
    std::lock_guard<std::mutex> lock(g_io_mutex);
    return g_states[pin];
}

bool togglePin(std::uint32_t pin) noexcept {
    if (pin >= MaxPins) {
        return false;
    }
    std::lock_guard<std::mutex> lock(g_io_mutex);
    g_states[pin] = (g_states[pin] == PinState::High) ? PinState::Low : PinState::High;
    return true;
}

}  // namespace TouRTOS::Drivers
