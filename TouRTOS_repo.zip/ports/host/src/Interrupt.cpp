#include "TouRTOS/drivers/Interrupt.h"

#include <array>

namespace TouRTOS::Drivers {

namespace {
constexpr std::size_t MaxInterrupts = 64U;
std::array<InterruptHandler, MaxInterrupts> g_handlers{};
}  // namespace

bool attachInterrupt(std::uint32_t irq, InterruptHandler handler) noexcept {
    if (irq >= MaxInterrupts) {
        return false;
    }
    g_handlers[irq] = handler;
    return true;
}

void enableInterrupt(std::uint32_t) noexcept {}

void disableInterrupt(std::uint32_t) noexcept {}

}  // namespace TouRTOS::Drivers
