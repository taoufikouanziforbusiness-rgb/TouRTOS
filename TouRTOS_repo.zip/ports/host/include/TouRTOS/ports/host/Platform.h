#pragma once

#include <array>
#include <string_view>

namespace TouRTOS::Ports::Host {

constexpr const char* Name = "host";
constexpr const char* ActiveMcuName = "native-host";
inline constexpr std::array<std::string_view, 1U> SupportedMcuNames{"native-host"};

constexpr bool isSupportedMcu(std::string_view name) noexcept {
    return name == SupportedMcuNames[0];
}

}  // namespace TouRTOS::Ports::Host
